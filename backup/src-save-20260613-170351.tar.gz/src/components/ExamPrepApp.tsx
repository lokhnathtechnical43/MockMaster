'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  BookOpen, Trophy, Clock, CheckCircle2, XCircle, SkipForward,
  ChevronRight, ChevronLeft, Home, User, ArrowLeft, X,
  Play, Zap, Target, Award, Timer, RefreshCw, BookMarked,
  GraduationCap, Shield, Building, Building2, Train, ShieldCheck, Swords,
  LogOut, Loader2, Mail, AlertTriangle, Settings, Bell,
  ChevronDown, Star, Flame, TrendingUp, Calendar, Gift,
  HelpCircle, Share2, MessageCircle, Crown,
  Menu, BookmarkPlus, Download, BarChart3, Wifi,
  ClipboardList, PenTool, Calculator, Camera, MapPin, Phone,
  Edit3, Save, ChevronUp, Monitor, Users, IndianRupee, Globe,
  ExternalLink, FileText, Lock, UserPlus
} from 'lucide-react'
import {
  getCategories as getLocalCategories, getTestsByExam as getLocalTestsByExam,
  getTestById as getLocalTestById, saveResult as saveLocalResult,
  getLeaderboard as getLocalLeaderboard, seedLocalData,
  type LocalExamCategory, type LocalExam, type LocalTest, type LocalQuestion, type TestResult
} from '@/lib/local-data'
import {
  getCategories as getFsCategories, getTests as getFsTests,
  getTestById as getFsTestById, saveResult as saveFsResult,
  getLeaderboard as getFsLeaderboard, getUseFirestore,
  getAnnouncements as getFsAnnouncements, getNotifications as getFsNotifications,
  getUpcomingExams as getFsUpcomingExams, getDailyTips as getFsDailyTips,
  getPrevYearPapers as getFsPrevYearPapers, getSidebarMenu as getFsSidebarMenu,
  getResults as getFsResults, updateUserTestStats,
} from '@/lib/firestore-service'
import { useFirebaseAuth } from '@/lib/use-firebase-auth'
import LoginModal from '@/components/LoginModal'
import { App } from '@capacitor/app'
import { Share } from '@capacitor/share'
import { Filesystem, Directory } from '@capacitor/filesystem'
import jsPDF from 'jspdf'
import { getAnnouncements as getLocalAnnouncements, getNotifications as getLocalNotifications, getUpcomingExams as getLocalUpcomingExams, getDailyTips as getLocalDailyTips, getPrevYearPapers as getLocalPrevYearPapers, getSidebarMenu as getLocalSidebarMenu, getReadNotifIds, markNotifAsRead, markAllNotifsAsRead, type UpcomingExam, type DailyTip, type PrevYearPaper, type PaperQuestion, type SidebarMenuItem } from '@/lib/admin-data'
import { t, type Lang } from '@/lib/i18n'

// ===== Types =====
type Page = 'home' | 'exams' | 'tests' | 'test-info' | 'test-taking' | 'results' | 'leaderboard' | 'profile' | 'practice' | 'bookmarks' | 'perf-report' | 'daily-routine' | 'prev-papers' | 'your-exam' | 'upcoming-exam-detail' | 'daily-tip-detail' | 'announcement-detail' | 'notification-detail'

// ===== Unified Data Access (Firestore or Local) =====
const isFirestore = () => getUseFirestore()

async function fetchCategories(): Promise<LocalExamCategory[]> {
  if (isFirestore()) return getFsCategories()
  return getLocalCategories()
}
async function fetchTestsByExam(examId: string): Promise<LocalTest[]> {
  if (isFirestore()) return getFsTests(examId)
  return getLocalTestsByExam(examId)
}
async function fetchTestById(testId: string): Promise<LocalTest | undefined> {
  if (isFirestore()) return getFsTestById(testId) as Promise<LocalTest | undefined>
  return getLocalTestById(testId)
}
async function fetchLeaderboard(testId: string): Promise<TestResult[]> {
  if (isFirestore()) return getFsLeaderboard(testId) as Promise<TestResult[]>
  return getLocalLeaderboard(testId)
}
async function storeResult(data: Omit<TestResult, 'id' | 'createdAt'>): Promise<TestResult> {
  if (isFirestore()) return saveFsResult(data) as Promise<TestResult>
  return saveLocalResult(data)
}

interface CategoryColor {
  bg: string
  text: string
  border: string
  light: string
  gradient: string
}

// ===== Constants =====
const CATEGORY_COLORS: Record<string, CategoryColor> = {
  ssc: { bg: 'bg-orange-500', text: 'text-orange-600', border: 'border-orange-300', light: 'bg-orange-50', gradient: 'from-orange-500 to-orange-600' },
  banking: { bg: 'bg-emerald-500', text: 'text-emerald-600', border: 'border-emerald-300', light: 'bg-emerald-50', gradient: 'from-emerald-500 to-emerald-600' },
  railways: { bg: 'bg-blue-500', text: 'text-blue-600', border: 'border-blue-300', light: 'bg-blue-50', gradient: 'from-blue-500 to-blue-600' },
  'state-govt': { bg: 'bg-purple-500', text: 'text-purple-600', border: 'border-purple-300', light: 'bg-purple-50', gradient: 'from-purple-500 to-purple-600' },
  teaching: { bg: 'bg-pink-500', text: 'text-pink-600', border: 'border-pink-300', light: 'bg-pink-50', gradient: 'from-pink-500 to-pink-600' },
  defence: { bg: 'bg-amber-500', text: 'text-amber-600', border: 'border-amber-300', light: 'bg-amber-50', gradient: 'from-amber-500 to-amber-600' },
  police: { bg: 'bg-red-500', text: 'text-red-600', border: 'border-red-300', light: 'bg-red-50', gradient: 'from-red-500 to-red-600' },
}

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  ssc: <BookOpen className="w-5 h-5" />,
  banking: <Building className="w-5 h-5" />,
  railways: <Train className="w-5 h-5" />,
  'state-govt': <Shield className="w-5 h-5" />,
  teaching: <GraduationCap className="w-5 h-5" />,
  defence: <Swords className="w-5 h-5" />,
  police: <ShieldCheck className="w-5 h-5" />,
}

// Map icon name strings to React icon components for admin-managed sidebar
const SIDEBAR_ICON_MAP: Record<string, React.ElementType> = {
  Home, BookOpen, Trophy, Zap, BookmarkPlus, BarChart3, FileText, Target, Clock,
}

// Default sidebar menu items (used when sidebarMenu is empty)
const DEFAULT_SIDEBAR_MENU_ITEMS = [
  { id: '1', icon: 'Home', label: 'Home', page: 'home', gradient: 'from-orange-500 to-amber-500', visible: true, order: 1 },
  { id: '2', icon: 'BookOpen', label: 'All Exams', page: 'exams', gradient: 'from-blue-500 to-indigo-500', visible: true, order: 2 },
  { id: '3', icon: 'Trophy', label: 'Leaderboard', page: 'leaderboard', gradient: 'from-yellow-500 to-orange-500', visible: true, order: 3 },
  { id: '4', icon: 'Zap', label: 'Quick Practice', page: 'practice', gradient: 'from-amber-400 to-orange-500', visible: true, order: 4 },
  { id: '5', icon: 'BookmarkPlus', label: 'Bookmarks', page: 'bookmarks', gradient: 'from-rose-400 to-pink-500', visible: true, order: 5 },
  { id: '6', icon: 'BarChart3', label: 'Performance', page: 'perf-report', gradient: 'from-emerald-400 to-teal-500', visible: true, order: 6 },
  { id: '7', icon: 'FileText', label: 'Prev. Papers', page: 'prev-papers', gradient: 'from-blue-400 to-cyan-500', visible: true, order: 7 },
  { id: '8', icon: 'Target', label: 'Your Exam', page: 'your-exam', gradient: 'from-violet-400 to-purple-500', visible: true, order: 8 },
  { id: '9', icon: 'Clock', label: 'Daily Routine', page: 'daily-routine', gradient: 'from-sky-400 to-blue-500', visible: true, order: 9 },
]

// Map page names to light bg and text colors
const SIDEBAR_PAGE_COLORS: Record<string, { lightBg: string; textColor: string }> = {
  home: { lightBg: 'bg-orange-50', textColor: 'text-orange-700' },
  exams: { lightBg: 'bg-blue-50', textColor: 'text-blue-700' },
  leaderboard: { lightBg: 'bg-yellow-50', textColor: 'text-yellow-700' },
  practice: { lightBg: 'bg-amber-50', textColor: 'text-amber-700' },
  bookmarks: { lightBg: 'bg-rose-50', textColor: 'text-rose-700' },
  'perf-report': { lightBg: 'bg-emerald-50', textColor: 'text-emerald-700' },
  'prev-papers': { lightBg: 'bg-blue-50', textColor: 'text-blue-700' },
  'your-exam': { lightBg: 'bg-violet-50', textColor: 'text-violet-700' },
  'daily-routine': { lightBg: 'bg-sky-50', textColor: 'text-sky-700' },
}

// ===== Helper Functions =====
function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
}

function getCatColor(slug: string): CategoryColor {
  return CATEGORY_COLORS[slug] || CATEGORY_COLORS.ssc
}

function getCatIcon(slug: string): React.ReactNode {
  return CATEGORY_ICONS[slug] || <BookOpen className="w-5 h-5" />
}

// ===== Main Component =====
export default function ExamPrepApp() {
  // --- Auth ---
  const auth = useFirebaseAuth()

  // --- Page / Navigation ---
  const [currentPage, setCurrentPage] = useState<Page>('home')
  const pageHistoryRef = useRef<Page[]>([])
  const scrollPositionsRef = useRef<Map<Page, number>>(new Map())
  const currentPageRef = useRef<Page>('home')

  // --- Data ---
  const [categories, setCategories] = useState<LocalExamCategory[]>([])
  const [selectedCategory, setSelectedCategory] = useState<LocalExamCategory | null>(null)
  const [selectedExam, setSelectedExam] = useState<LocalExam | null>(null)
  const [examTests, setExamTests] = useState<LocalTest[]>([])
  const [selectedTest, setSelectedTest] = useState<LocalTest | null>(null)

  // --- Test Taking ---
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [markedForReview, setMarkedForReview] = useState<Set<string>>(new Set())
  const [timeLeft, setTimeLeft] = useState(0)
  const [testActive, setTestActive] = useState(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const carouselRef = useRef<HTMLDivElement | null>(null)
  const carouselTimerRef = useRef<NodeJS.Timeout | null>(null)
  const sideMenuScrollRef = useRef<{ y: number; x: number; t: number; scrolled?: boolean } | null>(null)

  // --- Results ---
  const [lastResult, setLastResult] = useState<TestResult | null>(null)
  const [leaderboardData, setLeaderboardData] = useState<TestResult[]>([])
  const [leaderboardTestId, setLeaderboardTestId] = useState<string>('')

  // --- UI State ---
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showBackConfirm, setShowBackConfirm] = useState(false)
  const [showLanguageSheet, setShowLanguageSheet] = useState(false)
  const [showAboutSheet, setShowAboutSheet] = useState(false)
  const [showFaqSheet, setShowFaqSheet] = useState(false)
  const [selectedLanguage, setSelectedLanguage] = useState<Lang>('en')
  const [showQuestionNav, setShowQuestionNav] = useState(false)
  const [showSideMenu, setShowSideMenu] = useState(false)
  const [showNotificationPanel, setShowNotificationPanel] = useState(false)
  const [userStats, setUserStats] = useState({ testsTaken: 0, avgScore: 0, bestRank: 0 })
  const [showExitConfirm, setShowExitConfirm] = useState(false)
  const [showGuestAuthModal, setShowGuestAuthModal] = useState(false)
  const [guestAuthMode, setGuestAuthMode] = useState<'qp-limit' | 'login-required'>('login-required')
  const [currentTestMode, setCurrentTestMode] = useState<'real' | 'practice'>('real') // Track if current test is real or practice
  const [showAnswerKey, setShowAnswerKey] = useState(false)
  const [pdfSharing, setPdfSharing] = useState(false)

  // --- Splash Screen ---
  const [showSplash, setShowSplash] = useState(true)
  const [splashFading, setSplashFading] = useState(false)

  // --- Bookmarks & User Preferences (localStorage) ---
  const [bookmarkedQs, setBookmarkedQs] = useState<string[]>([])
  const [userExamId, setUserExamId] = useState<string>('')
  const [dailyRoutine, setDailyRoutine] = useState<{ questionCount: number; preferredTime: string; examId: string }>({ questionCount: 10, preferredTime: 'morning', examId: '' })

  // --- Profile Data (localStorage) ---
  const [profileData, setProfileData] = useState({
    fullName: '',
    dateOfBirth: '',
    gender: '',
    category: '',
    address: '',
    education: '',
    targetExam: '',
    phone: '',
    state: '',
  })
  const [isEditingProfile, setIsEditingProfile] = useState(false)
  const [profileSaved, setProfileSaved] = useState(false)

  // Auto-close login modal when auth succeeds
  useEffect(() => {
    if (auth.isLoggedIn && showLoginModal) {
      setShowLoginModal(false)
      scrollPositionsRef.current.set(currentPage, window.scrollY)
      setCurrentPage('home')
    }
  }, [auth.isLoggedIn])

  // Refresh user stats when auth changes or after test completion
  useEffect(() => {
    if (auth.isLoggedIn) {
      getUserStats().then(setUserStats)
    } else {
      setUserStats({ testsTaken: 0, avgScore: 0, bestRank: 0 })
    }
  }, [auth.isLoggedIn, auth.getUserId(), lastResult])

  // Splash screen auto-dismiss after animation
  useEffect(() => {
    const fadeTimer = setTimeout(() => {
      setSplashFading(true)
    }, 2500)
    const removeTimer = setTimeout(() => {
      setShowSplash(false)
    }, 3000)
    return () => { clearTimeout(fadeTimer); clearTimeout(removeTimer) }
  }, [])

  // Load bookmarks & preferences from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mockmaster_bookmarks')
      if (saved) setBookmarkedQs(JSON.parse(saved))
    } catch {}
    try {
      const saved = localStorage.getItem('mockmaster_user_exam')
      if (saved) setUserExamId(saved)
    } catch {}
    try {
      const saved = localStorage.getItem('mockmaster_daily_routine')
      if (saved) setDailyRoutine(JSON.parse(saved))
    } catch {}
    try {
      const saved = localStorage.getItem('mockmaster_profile')
      if (saved) setProfileData(JSON.parse(saved))
    } catch {}
  }, [])

  // Save bookmarks when changed
  useEffect(() => {
    try { localStorage.setItem('mockmaster_bookmarks', JSON.stringify(bookmarkedQs)) } catch {}
  }, [bookmarkedQs])
  useEffect(() => {
    try { localStorage.setItem('mockmaster_user_exam', userExamId) } catch {}
  }, [userExamId])
  useEffect(() => {
    try { localStorage.setItem('mockmaster_daily_routine', JSON.stringify(dailyRoutine)) } catch {}
  }, [dailyRoutine])
  useEffect(() => {
    try { localStorage.setItem('mockmaster_profile', JSON.stringify(profileData)) } catch {}
  }, [profileData])

  function toggleBookmark(questionId: string) {
    setBookmarkedQs(prev => prev.includes(questionId) ? prev.filter(id => id !== questionId) : [...prev, questionId])
  }

  // i18n shorthand
  const lng = selectedLanguage
  const _t = (key: string) => t(key, lng)

  // --- Notifications ---
  const [notifications, setNotifications] = useState<
    { id: string; title: string; message: string; time: string; read: boolean; type: 'update' | 'alert' | 'info'; imageUrl?: string; actionUrl?: string }[]
  >([])
  const [selectedNotification, setSelectedNotification] = useState<{ id: string; title: string; message: string; time: string; read: boolean; type: 'update' | 'alert' | 'info'; imageUrl?: string; actionUrl?: string } | null>(null)
  const unreadCount = notifications.filter(n => !n.read).length

  // --- Announcements ---
  const [announcements, setAnnouncements] = useState<
    { id: string; image: string; imageUrl?: string; title: string; subtitle: string; action: Page; gradient: string }[]
  >([])
  const [activeAnnouncement, setActiveAnnouncement] = useState(0)
  const [upcomingExams, setUpcomingExams] = useState<UpcomingExam[]>([])
  const [selectedUpcomingExam, setSelectedUpcomingExam] = useState<UpcomingExam | null>(null)
  const [dailyTips, setDailyTips] = useState<DailyTip[]>([])
  const [selectedDailyTip, setSelectedDailyTip] = useState<DailyTip | null>(null)
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<{ id: string; image: string; imageUrl?: string; title: string; subtitle: string; action: Page; gradient: string } | null>(null)
  const [prevPapers, setPrevPapers] = useState<PrevYearPaper[]>([])
  const [sidebarMenu, setSidebarMenu] = useState<SidebarMenuItem[]>([])
  const [selectedPaperYear, setSelectedPaperYear] = useState<string>('')



  // --- Load categories + data on mount ---
  useEffect(() => {
    const loadData = async () => {
      // Seed local data on first load (if localStorage is empty)
      seedLocalData()

      // Always load categories from local (which merges localStorage + defaults)
      const cats = getLocalCategories()
      setCategories(cats)

      // Also try Firestore if available, but local is the primary source
      try {
        if (isFirestore()) {
          const fsCats = await fetchCategories()
          if (fsCats.length > 0) setCategories(fsCats)
        }
      } catch (e) {
        console.warn('Firestore categories load failed, using local:', e)
      }

      const readIds = getReadNotifIds()

      // Load admin data - always from local first, then Firestore if available
      setAnnouncements(getLocalAnnouncements().map(a => ({ ...a, action: a.action as Page })))
      setNotifications(getLocalNotifications().map(n => ({ ...n, read: n.read || readIds.has(n.id) })))
      setUpcomingExams(getLocalUpcomingExams())
      setDailyTips(getLocalDailyTips())
      const localPapers = getLocalPrevYearPapers()
      setPrevPapers(localPapers)
      if (localPapers.length > 0) {
        const paperYears = [...new Set(localPapers.map(p => p.year))].sort((a, b) => Number(b) - Number(a))
        setSelectedPaperYear(paperYears[0] || '')
      }
      setSidebarMenu(getLocalSidebarMenu().filter(i => i.visible))

      // If Firestore is available, also load from there (overrides local)
      if (isFirestore()) {
        getFsAnnouncements()
          .then(anns => { if (anns.length > 0) setAnnouncements(anns.map(a => ({ ...a, action: a.action as Page }))) })
          .catch(() => {})

        getFsNotifications()
          .then(notifs => { if (notifs.length > 0) setNotifications(notifs.map(n => ({ ...n, read: n.read || readIds.has(n.id) }))) })
          .catch(() => {})

        getFsUpcomingExams()
          .then(upcoming => { if (upcoming.length > 0) setUpcomingExams(upcoming) })
          .catch(() => {})

        getFsDailyTips()
          .then(tips => { if (tips.length > 0) setDailyTips(tips) })
          .catch(() => {})

        getFsPrevYearPapers()
          .then(papers => {
            if (papers.length > 0) {
              setPrevPapers(papers)
              const years = [...new Set(papers.map(p => p.year))].sort((a, b) => Number(b) - Number(a))
              setSelectedPaperYear(years[0] || '')
            }
          })
          .catch(() => {})

        getFsSidebarMenu()
          .then(items => { if (items.length > 0) setSidebarMenu(items.filter(i => i.visible)) })
          .catch(() => {})
      }
    }
    loadData()
  }, [])

  // --- Listen for data changes (localStorage updates + Firestore refresh) ---
  useEffect(() => {
    const handleDataRefresh = async () => {
      const readIds = getReadNotifIds()

      // Always refresh from local first (immediate, always works)
      setCategories(getLocalCategories())
      setAnnouncements(getLocalAnnouncements().map(a => ({ ...a, action: a.action as Page })))
      setNotifications(getLocalNotifications().map(n => ({ ...n, read: n.read || readIds.has(n.id) })))
      setUpcomingExams(getLocalUpcomingExams())
      setDailyTips(getLocalDailyTips())
      const localPapers = getLocalPrevYearPapers()
      setPrevPapers(localPapers)
      if (localPapers.length > 0) {
        const years = [...new Set(localPapers.map(p => p.year))].sort((a, b) => Number(b) - Number(a))
        setSelectedPaperYear(years[0] || '')
      }
      setSidebarMenu(getLocalSidebarMenu().filter(i => i.visible))

      // If Firestore is available, also refresh from there
      if (isFirestore()) {
        getFsAnnouncements()
          .then(anns => { if (anns.length > 0) setAnnouncements(anns.map(a => ({ ...a, action: a.action as Page }))) })
          .catch(() => {})

        getFsNotifications()
          .then(notifs => { if (notifs.length > 0) setNotifications(notifs.map(n => ({ ...n, read: n.read || readIds.has(n.id) }))) })
          .catch(() => {})

        getFsUpcomingExams()
          .then(upcoming => { if (upcoming.length > 0) setUpcomingExams(upcoming) })
          .catch(() => {})

        getFsDailyTips()
          .then(tips => { if (tips.length > 0) setDailyTips(tips) })
          .catch(() => {})

        getFsPrevYearPapers()
          .then(papers => {
            if (papers.length > 0) {
              setPrevPapers(papers)
              const years = [...new Set(papers.map(p => p.year))].sort((a, b) => Number(b) - Number(a))
              setSelectedPaperYear(years[0] || '')
            }
          })
          .catch(() => {})

        getFsSidebarMenu()
          .then(items => { if (items.length > 0) setSidebarMenu(items.filter(i => i.visible)) })
          .catch(() => {})
      }
    }
    window.addEventListener('storage', handleDataRefresh)
    const interval = setInterval(handleDataRefresh, 30000) // Refresh every 30 seconds
    return () => {
      window.removeEventListener('storage', handleDataRefresh)
      clearInterval(interval)
    }
  }, [])

  // --- Auto-scroll carousel ---
  useEffect(() => {
    const startCarousel = () => {
      carouselTimerRef.current = setInterval(() => {
        setActiveAnnouncement(prev => {
          const next = (prev + 1) % announcements.length
          // Scroll the carousel container
          if (carouselRef.current) {
            const cardWidth = carouselRef.current.children[0]?.getBoundingClientRect().width || 250
            const gap = 12 // gap-3 = 12px
            carouselRef.current.scrollTo({
              left: next * (cardWidth + gap),
              behavior: 'smooth'
            })
          }
          return next
        })
      }, 3000) // 3 seconds interval
    }
    startCarousel()
    return () => {
      if (carouselTimerRef.current) clearInterval(carouselTimerRef.current)
    }
  }, [announcements.length])

  // --- Navigation ---
  const navigateTo = useCallback((page: Page) => {
    // Save scroll position of current page before leaving
    scrollPositionsRef.current.set(currentPage, window.scrollY)
    pageHistoryRef.current.push(currentPage)
    setCurrentPage(page)
  }, [currentPage])

  const goBack = useCallback(() => {
    // Save scroll position of current page before leaving
    scrollPositionsRef.current.set(currentPage, window.scrollY)
    const prev = pageHistoryRef.current.pop()
    if (prev) {
      setCurrentPage(prev)
    } else {
      setCurrentPage('home')
    }
  }, [currentPage])

  // --- Handle mobile back button (Capacitor + Browser) ---
  const handleBackButton = useCallback(() => {
    // If exit confirmation is showing, close it
    if (showExitConfirm) {
      setShowExitConfirm(false)
      return
    }
    // If back confirmation is showing, close it
    if (showBackConfirm) {
      setShowBackConfirm(false)
      return
    }
    // If notification panel is open, close it
    if (showNotificationPanel) {
      setShowNotificationPanel(false)
      return
    }
    // If side menu is open, close it
    if (showSideMenu) {
      setShowSideMenu(false)
      return
    }
    // If question nav panel is open, close it
    if (showQuestionNav) {
      setShowQuestionNav(false)
      return
    }
    // If login modal is open, close it
    if (showLoginModal) {
      setShowLoginModal(false)
      return
    }
    // If language sheet is open, close it
    if (showLanguageSheet) {
      setShowLanguageSheet(false)
      return
    }
    // If about sheet is open, close it
    if (showAboutSheet) {
      setShowAboutSheet(false)
      return
    }
    // If FAQ sheet is open, close it
    if (showFaqSheet) {
      setShowFaqSheet(false)
      return
    }
    // If taking a test, show confirmation
    if (currentPage === 'test-taking' && testActive) {
      setShowBackConfirm(true)
      return
    }
    // If on home page, show exit confirmation instead of directly exiting
    if (currentPage === 'home') {
      setShowExitConfirm(true)
      return
    }
    // For all other pages, simply go back in history
    if (pageHistoryRef.current.length > 0) {
      goBack()
    } else {
      scrollPositionsRef.current.set(currentPage, window.scrollY)
      setCurrentPage('home')
    }
  }, [currentPage, testActive, showBackConfirm, showExitConfirm, showSideMenu, showQuestionNav, showLoginModal, showLanguageSheet, showAboutSheet, showFaqSheet, showNotificationPanel, goBack])

  // Capacitor hardware back button
  useEffect(() => {
    let handler: any
    const setupBackButton = async () => {
      try {
        handler = await App.addListener('backButton', () => {
          handleBackButton()
        })
      } catch (e) {
        // Not running in Capacitor, ignore
      }
    }
    setupBackButton()
    return () => {
      handler?.remove?.()
    }
  }, [handleBackButton])

  // --- Content Protection: Block copy, screenshot, print on test pages ---
  const [secureBlurActive, setSecureBlurActive] = useState(false)

  useEffect(() => {
    // Protect all pages where questions/answers are displayed
    const isSecurePage = testActive || currentPage === 'test-taking' || currentPage === 'results' || currentPage === 'bookmarks' || currentPage === 'practice'
    if (!isSecurePage) return

    // Block keyboard shortcuts: Ctrl+C, Ctrl+P, Ctrl+S, Ctrl+A, PrintScreen, F12
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+C (copy)
      if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        e.preventDefault()
        return false
      }
      // Ctrl+A (select all)
      if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
        e.preventDefault()
        return false
      }
      // Ctrl+P (print)
      if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault()
        return false
      }
      // Ctrl+S (save)
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault()
        return false
      }
      // Ctrl+U (view source)
      if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
        e.preventDefault()
        return false
      }
      // PrintScreen
      if (e.key === 'PrintScreen') {
        e.preventDefault()
        // Clear clipboard
        navigator.clipboard?.writeText('').catch(() => {})
        return false
      }
      // F12 (dev tools)
      if (e.key === 'F12') {
        e.preventDefault()
        return false
      }
      // Ctrl+Shift+I (dev tools)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'I') {
        e.preventDefault()
        return false
      }
      // Ctrl+Shift+J (console)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'J') {
        e.preventDefault()
        return false
      }
      // Ctrl+Shift+C (inspect element)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'C') {
        e.preventDefault()
        return false
      }
    }

    // Block copy/cut events
    const handleCopy = (e: Event) => {
      e.preventDefault()
      return false
    }

    const handleCut = (e: Event) => {
      e.preventDefault()
      return false
    }

    // Block right-click
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault()
      return false
    }

    // Block drag events (prevent dragging text/images)
    const handleDragStart = (e: DragEvent) => {
      e.preventDefault()
      return false
    }

    // Detect text selection and clear it immediately
    const handleSelectionChange = () => {
      const selection = window.getSelection()
      if (selection && selection.toString().length > 0) {
        selection.removeAllRanges()
      }
    }

    // Blur on visibility change (anti-screenshot when switching apps)
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setSecureBlurActive(true)
      } else {
        // Small delay before removing blur (in case of quick screenshot)
        setTimeout(() => setSecureBlurActive(false), 500)
      }
    }

    // Blur on window blur (Alt+Tab, etc.)
    const handleWindowBlur = () => {
      setSecureBlurActive(true)
    }
    const handleWindowFocus = () => {
      setTimeout(() => setSecureBlurActive(false), 500)
    }

    // Block print via CSS media
    const style = document.createElement('style')
    style.id = 'secure-print-style'
    style.textContent = '@media print { body * { display: none !important; } body::after { content: "Printing is not allowed"; display: block; text-align: center; padding: 50px; font-size: 24px; font-weight: bold; } }'
    document.head.appendChild(style)

    // Add event listeners
    document.addEventListener('keydown', handleKeyDown)
    document.addEventListener('copy', handleCopy)
    document.addEventListener('cut', handleCut)
    document.addEventListener('contextmenu', handleContextMenu)
    document.addEventListener('dragstart', handleDragStart)
    document.addEventListener('selectionchange', handleSelectionChange)
    document.addEventListener('visibilitychange', handleVisibilityChange)
    window.addEventListener('blur', handleWindowBlur)
    window.addEventListener('focus', handleWindowFocus)

    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.removeEventListener('copy', handleCopy)
      document.removeEventListener('cut', handleCut)
      document.removeEventListener('contextmenu', handleContextMenu)
      document.removeEventListener('dragstart', handleDragStart)
      document.removeEventListener('selectionchange', handleSelectionChange)
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      window.removeEventListener('blur', handleWindowBlur)
      window.removeEventListener('focus', handleWindowFocus)
      // Remove print style
      const printStyle = document.getElementById('secure-print-style')
      if (printStyle) printStyle.remove()
    }
  }, [testActive, currentPage])

  // Browser popstate (for web/PWA)
  useEffect(() => {
    const handlePopState = () => {
      handleBackButton()
      // Re-push state so browser doesn't navigate away
      window.history.pushState(null, '')
    }
    window.addEventListener('popstate', handlePopState)
    return () => window.removeEventListener('popstate', handlePopState)
  }, [handleBackButton])

  // Push state on navigation so browser back button fires popstate
  useEffect(() => {
    window.history.pushState(null, '')
  }, [currentPage])

  // --- Restore scroll position on page change ---
  useEffect(() => {
    // When page changes, restore saved scroll position
    const savedY = scrollPositionsRef.current.get(currentPage)
    if (savedY !== undefined) {
      // Use requestAnimationFrame to ensure DOM has rendered
      requestAnimationFrame(() => {
        window.scrollTo(0, savedY!)
      })
    } else {
      // New page (not visited before) - scroll to top
      window.scrollTo(0, 0)
    }
    currentPageRef.current = currentPage
  }, [currentPage])

  // --- Timer ---
  useEffect(() => {
    if (testActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!)
            handleFinishTest()
            return 0
          }
          return prev - 1
        })
      }, 1000)
      return () => {
        if (timerRef.current) clearInterval(timerRef.current)
      }
    }
  }, [testActive])

  // --- Auth Gate for non-account Users ---
  function requireAuth(): boolean {
    if (auth.needsRealAccount) {
      setGuestAuthMode('login-required')
      setShowGuestAuthModal(true)
      return false
    }
    return true
  }

  // --- Test Functions ---
  async function startTest(test: LocalTest, mode: 'real' | 'practice' = 'real') {
    // Gate: users without real account cannot start any test
    if (auth.needsRealAccount) {
      setGuestAuthMode('login-required')
      setShowGuestAuthModal(true)
      return
    }
    const fullTest = await fetchTestById(test.id)
    if (!fullTest) {
      console.error('[App] startTest: Could not fetch test with id:', test.id)
      return
    }
    if (!fullTest.questions || fullTest.questions.length === 0) {
      console.error('[App] startTest: Test has no questions! Test id:', test.id, 'Test title:', fullTest.title)
      console.error('[App] This usually means the questions were not seeded to Firestore. Go to Admin Panel → Dashboard → Seed Database.')
    }
    setSelectedTest(fullTest)
    setAnswers({})
    setMarkedForReview(new Set())
    setCurrentQuestionIndex(0)
    setTimeLeft(fullTest.duration * 60)
    setTestActive(true)
    setCurrentTestMode(mode)
    navigateTo('test-taking')
  }

  // --- Quick Practice with Guest Limit ---
  async function handleQuickPractice() {
    // Check if user without account has already used Quick Practice
    if (auth.needsRealAccount && !auth.canGuestUseQuickPractice) {
      setGuestAuthMode('qp-limit')
      setShowGuestAuthModal(true)
      return
    }
    const allCats = categories
    const allExams = allCats.flatMap(c => c.exams)
    if (allExams.length === 0) return
    // Try to find an exam with tests that have questions
    for (let attempt = 0; attempt < Math.min(allExams.length, 10); attempt++) {
      const randomExam = allExams[Math.floor(Math.random() * allExams.length)]
      const randomCat = allCats.find(c => c.exams.some(e => e.id === randomExam.id))
      if (!randomCat) continue
      const tests = await fetchTestsByExam(randomExam.id)
      if (tests.length > 0) {
        // Find a test with questions
        for (const test of tests) {
          const fullTest = await fetchTestById(test.id)
          if (fullTest && fullTest.questions && fullTest.questions.length > 0) {
            setSelectedExam(randomExam)
            setSelectedCategory(randomCat)
            setExamTests(tests)
            setCurrentTestMode('practice')
            // Directly set up test (bypass startTest guest gate since this is Quick Practice)
            setSelectedTest(fullTest)
            setAnswers({})
            setMarkedForReview(new Set())
            setCurrentQuestionIndex(0)
            setTimeLeft(fullTest.duration * 60)
            setTestActive(true)
            navigateTo('test-taking')
            // Mark that free Quick Practice has been used
            if (auth.needsRealAccount) {
              auth.markGuestQuickPracticeUsed()
            }
            return
          }
        }
      }
    }
  }

  async function handleFinishTest() {
    if (timerRef.current) clearInterval(timerRef.current)
    setTestActive(false)

    if (!selectedTest) return

    const test = selectedTest
    const totalQuestions = test.questions.length
    let correctCount = 0
    let wrongCount = 0
    let skippedCount = 0

    test.questions.forEach(q => {
      const userAnswer = answers[q.id]
      if (!userAnswer) {
        skippedCount++
      } else if (userAnswer === q.correctAnswer) {
        correctCount++
      } else {
        wrongCount++
      }
    })

    const score = correctCount * test.correctMarks - wrongCount * Math.abs(test.wrongMarks)
    const maxScore = totalQuestions * test.correctMarks
    const timeTaken = test.duration * 60 - timeLeft

    const result = await storeResult({
      testId: test.id,
      testName: test.title,
      examName: selectedExam?.name || '',
      userId: auth.getUserId() || 'anonymous',
      correctCount,
      wrongCount,
      skippedCount,
      score,
      maxScore,
      timeTaken,
      totalQuestions,
      answers,
      mode: currentTestMode,
    })

    setLastResult(result)

    // Save to localStorage for local stats/leaderboard (only if not already saved by storeResult)
    if (!isFirestore()) {
      // In local mode, storeResult already saves to localStorage, so skip duplicate
    } else {
      // In Firestore mode, also save to localStorage for offline access and leaderboard
      try {
        const perfData = localStorage.getItem('examprep_results')
        const perfResults: any[] = perfData ? JSON.parse(perfData) : []
        perfResults.push({
          ...result,
          testName: test.title,
          examName: selectedExam?.name || '',
          totalQuestions,
          mode: currentTestMode,
        })
        localStorage.setItem('examprep_results', JSON.stringify(perfResults))
      } catch (e) {}
    }

    // Update Firestore user test stats
    if (isFirestore() && auth.getUserId()) {
      updateUserTestStats(auth.getUserId()!, score).catch(e =>
        console.warn('[Test] updateUserTestStats failed:', e)
      )
    }

    navigateTo('results')
  }

  function selectAnswer(questionId: string, option: string) {
    setAnswers(prev => ({ ...prev, [questionId]: option }))
  }

  function clearAnswer(questionId: string) {
    setAnswers(prev => {
      const copy = { ...prev }
      delete copy[questionId]
      return copy
    })
  }

  function toggleReview(questionId: string) {
    setMarkedForReview(prev => {
      const next = new Set(prev)
      if (next.has(questionId)) next.delete(questionId)
      else next.add(questionId)
      return next
    })
  }

  // --- Stats from localStorage (only REAL exams, not practice) ---
  async function getUserStats() {
    try {
      let results: TestResult[] = []
      const userId = auth.getUserId()

      // Try Firestore first when enabled
      if (isFirestore() && userId) {
        try {
          const fsResults = await getFsResults(undefined, userId)
          if (fsResults && fsResults.length > 0) {
            results = fsResults.map((r: any) => ({
              ...r,
              totalQuestions: r.totalQuestions || (r.maxScore > 0 ? Math.round(r.maxScore / 1) : r.correctCount + r.wrongCount + r.skippedCount),
              userName: r.userName || r.userId || '',
            }))
          }
        } catch (e) {
          console.warn('[Stats] Firestore fetch failed, falling back to local:', e)
        }
      }

      // Fallback to localStorage
      if (results.length === 0) {
        const data = localStorage.getItem('examprep_results')
        if (data) {
          results = JSON.parse(data)
          if (userId) {
            results = results.filter((r: TestResult) => r.userId === userId)
          }
        }
      }

      // Filter: only count REAL exams for home page stats (not practice)
      const realExamResults = results.filter((r: TestResult) => !r.mode || r.mode === 'real')

      const testsTaken = realExamResults.length
      const avgScore = testsTaken > 0 ? Math.round(realExamResults.reduce((sum: number, r: TestResult) => sum + (r.score / (r.totalQuestions || r.correctCount + r.wrongCount + r.skippedCount || 1)) * 100, 0) / testsTaken) : 0
      // Calculate best rank from leaderboard data across all REAL tests the user has taken
      let bestRank = 0
      if (userId && testsTaken > 0) {
        // For rank calculation, we need all results (not just user's)
        let allResults: TestResult[] = []
        if (isFirestore()) {
          try {
            allResults = await getFsResults() as TestResult[]
          } catch (e) {
            const data = localStorage.getItem('examprep_results')
            if (data) allResults = JSON.parse(data)
          }
        } else {
          const data = localStorage.getItem('examprep_results')
          if (data) allResults = JSON.parse(data)
        }
        const userTestIds = [...new Set(realExamResults.map((r: TestResult) => r.testId))]
        let bestFound = Infinity
        for (const testId of userTestIds) {
          const testResults = allResults.filter((r: TestResult) => r.testId === testId)
          testResults.sort((a: TestResult, b: TestResult) => {
            const scoreA = a.score / (a.totalQuestions || a.correctCount + a.wrongCount + a.skippedCount || 1)
            const scoreB = b.score / (b.totalQuestions || b.correctCount + b.wrongCount + b.skippedCount || 1)
            if (scoreB !== scoreA) return scoreB - scoreA
            return a.timeTaken - b.timeTaken
          })
          const rank = testResults.findIndex((r: TestResult) => r.userId === userId) + 1
          if (rank > 0 && rank < bestFound) bestFound = rank
        }
        bestRank = bestFound === Infinity ? 0 : bestFound
      }
      return { testsTaken, avgScore, bestRank }
    } catch {
      return { testsTaken: 0, avgScore: 0, bestRank: 0 }
    }
  }

  // --- Bottom nav handler ---
  function handleBottomNav(page: Page) {
    // Save scroll position of current page before leaving
    scrollPositionsRef.current.set(currentPage, window.scrollY)
    // If navigating to the same page, do nothing
    if (currentPage === page) return
    // Save current page to history so user can go back
    pageHistoryRef.current.push(currentPage)
    setCurrentPage(page)
  }

  // --- Exam select handler ---
  async function openExam(exam: LocalExam, category: LocalExamCategory, mode: 'real' | 'practice' = 'real') {
    setSelectedExam(exam)
    setSelectedCategory(category)
    setCurrentTestMode(mode)
    const tests = await fetchTestsByExam(exam.id)
    setExamTests(tests)
    navigateTo('tests')
  }

  async function openTestInfo(test: LocalTest) {
    const fullTest = await fetchTestById(test.id)
    if (fullTest) {
      setSelectedTest(fullTest)
      navigateTo('test-info')
    }
  }

  async function openLeaderboard(testId: string) {
    setLeaderboardTestId(testId)
    setLeaderboardData(await fetchLeaderboard(testId))
    navigateTo('leaderboard')
  }

  // --- Avatar display ---
  function getAvatarDisplay() {
    if (auth.isGuest) return 'G'
    const display = auth.getUserDisplay()
    if (display) {
      // For email: first letter before @, for name: first letter
      if (display.includes('@')) return display.charAt(0).toUpperCase()
      return display.charAt(0).toUpperCase()
    }
    return 'G'
  }

  // ===== RENDER: Home Page =====
  function renderHome() {
    const stats = userStats
    const totalTestsAvailable = categories.reduce((sum, c) => sum + c.exams.length, 0)
    const greetings = [_t('home.goodMorning'), _t('home.goodAfternoon'), _t('home.goodEvening')]
    const hour = new Date().getHours()
    const greeting = hour < 12 ? greetings[0] : hour < 17 ? greetings[1] : greetings[2]

    return (
      <div className="pb-20">
        {/* Professional Header with Stats */}
        <div className="bg-gradient-to-br from-orange-500 via-red-500 to-rose-500 px-4 pt-[calc(env(safe-area-inset-top,0px)+0.75rem)] pb-8 rounded-b-[2rem] relative overflow-hidden">
          {/* Decorative circles */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/4" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/4" />
          <div className="absolute top-1/2 right-1/4 w-16 h-16 bg-white/5 rounded-full" />

          <div className="relative z-10">
            {/* Top Bar */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <button
                  onClick={() => setShowSideMenu(true)}
                  onTouchEnd={(e) => { e.preventDefault(); setShowSideMenu(true) }}
                  className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center active:bg-white/25 transition-colors"
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                >
                  <Menu className="w-5 h-5 text-white" />
                </button>
                <div className="flex items-center gap-2">
                  <img src="/logo.png" alt="MockMaster" className="w-8 h-8 rounded-xl shadow-sm" />
                  <div>
                    <h1 className="text-white text-base font-extrabold leading-tight">{_t('app.name')}</h1>
                    <p className="text-orange-100 text-[10px] leading-tight">{_t('app.subtitle')}</p>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowNotificationPanel(!showNotificationPanel)}
                onTouchEnd={(e) => { e.preventDefault(); setShowNotificationPanel(!showNotificationPanel) }}
                className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center active:bg-white/25 transition-colors relative"
                style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
              >
                <Bell className="w-4 h-4 text-white" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-400 rounded-full flex items-center justify-center text-orange-800 text-[8px] font-bold">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>

            {/* Welcome + Stats Row */}
            <div className="mt-5 flex items-end justify-between">
              <div>
                <p className="text-white/80 text-sm">{greeting} 👋</p>
                {auth.isLoggedIn && (
                  <p className="text-white text-xl font-extrabold mt-0.5">{auth.user?.displayName || auth.user?.email?.split('@')[0] || auth.getUserDisplay()}</p>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <div className="bg-white/15 backdrop-blur rounded-xl px-3 py-2 text-center">
                  <p className="text-white font-extrabold text-lg leading-none">{stats.testsTaken || '-'}</p>
                  <p className="text-white/70 text-[9px] mt-0.5">{_t('home.testsDone')}</p>
                </div>
                <div className="bg-white/15 backdrop-blur rounded-xl px-3 py-2 text-center">
                  <p className="text-white font-extrabold text-lg leading-none">{stats.avgScore ? `${stats.avgScore}%` : '-'}</p>
                  <p className="text-white/70 text-[9px] mt-0.5">{_t('home.accuracy')}</p>
                </div>
                <div className="bg-white/15 backdrop-blur rounded-xl px-3 py-2 text-center">
                  <p className="text-white font-extrabold text-lg leading-none">{stats.bestRank ? `#${stats.bestRank}` : '-'}</p>
                  <p className="text-white/70 text-[9px] mt-0.5">{_t('home.bestRank')}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Notification Panel */}
        {showNotificationPanel && (
          <div className="px-4 -mt-4 mb-2 relative z-40">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-orange-50 to-red-50 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-orange-500" />
                  <h3 className="font-bold text-sm text-gray-800">{_t('home.notifications')}</h3>
                  {unreadCount > 0 && (
                    <Badge className="bg-orange-500 text-white text-[10px] px-1.5 py-0">{unreadCount} {_t('home.newNotifs')}</Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button
                      onClick={() => { setNotifications(prev => prev.map(n => ({ ...n, read: true }))); markAllNotifsAsRead(notifications.map(n => n.id)) }}
                      className="text-[11px] text-orange-500 font-semibold hover:text-orange-600"
                    >
                      {_t('home.markAllRead')}
                    </button>
                  )}
                  <button onClick={() => setShowNotificationPanel(false)} className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center">
                    <X className="w-3 h-3 text-gray-500" />
                  </button>
                </div>
              </div>
              <div className="max-h-[300px] overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="py-8 text-center">
                    <Bell className="w-8 h-8 text-gray-200 mx-auto mb-2" />
                    <p className="text-gray-400 text-sm">{_t('home.noNotifs')}</p>
                  </div>
                ) : (
                  notifications.map(notification => (
                    <div
                      key={notification.id}
                      onClick={() => { 
                        setNotifications(prev => prev.map(n => n.id === notification.id ? { ...n, read: true } : n)); 
                        markNotifAsRead(notification.id);
                        setSelectedNotification(notification);
                        setShowNotificationPanel(false);
                        navigateTo('notification-detail');
                      }}
                      className={`px-4 py-3 border-b border-gray-50 last:border-b-0 active:bg-gray-50 transition-colors cursor-pointer ${!notification.read ? 'bg-orange-50/50' : ''}`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 overflow-hidden ${notification.imageUrl ? '' : notification.type === 'update' ? 'bg-blue-100' : notification.type === 'alert' ? 'bg-amber-100' : 'bg-green-100'}`}>
                          {notification.imageUrl ? (
                            <img src={notification.imageUrl} alt="" className="w-8 h-8 object-cover rounded-full" />
                          ) : (
                            notification.type === 'update' ? <Zap className="w-4 h-4 text-blue-500" /> : notification.type === 'alert' ? <AlertTriangle className="w-4 h-4 text-amber-500" /> : <Gift className="w-4 h-4 text-green-500" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className={`text-sm ${!notification.read ? 'font-bold text-gray-900' : 'font-medium text-gray-700'}`}>{notification.title}</p>
                            {!notification.read && <div className="w-2 h-2 rounded-full bg-orange-500 flex-shrink-0" />}
                          </div>
                          <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{notification.message}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <p className="text-[10px] text-gray-400">{notification.time}</p>
                            {notification.actionUrl && <span className="text-[9px] text-orange-500 font-medium">Tap to open</span>}
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-300 flex-shrink-0 mt-2" />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Moving Announcements Marquee */}
        <div className="mx-4 -mt-4">
          <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="flex items-center">
              <div className="bg-gradient-to-r from-orange-500 to-red-500 px-2.5 py-2 flex items-center flex-shrink-0">
                <Flame className="w-3.5 h-3.5 text-white" />
              </div>
              <div className="overflow-hidden flex-1 py-2">
                <div className="flex animate-marquee whitespace-nowrap">
                  {announcements.map(a => (
                    <button key={a.id} onClick={() => handleBottomNav(a.action)} className="mx-6 text-[11px] font-medium text-gray-700 active:text-orange-600">
                      {a.title} — {a.subtitle}
                    </button>
                  ))}
                  {announcements.map(a => (
                    <button key={`dup-${a.id}`} onClick={() => handleBottomNav(a.action)} className="mx-6 text-[11px] font-medium text-gray-700 active:text-orange-600">
                      {a.title} — {a.subtitle}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Announcements - Image Banner Carousel - Only show when admin has added announcements */}
        {announcements.length > 0 && (
        <div className="px-4 mt-3 mb-1">
          <div className="relative">
            <div
              ref={carouselRef}
              onScroll={() => {
                if (carouselRef.current) {
                  const cardWidth = carouselRef.current.children[0]?.getBoundingClientRect().width || 300
                  const scrollPos = carouselRef.current.scrollLeft
                  const newIndex = Math.round(scrollPos / cardWidth)
                  if (newIndex !== activeAnnouncement && newIndex >= 0 && newIndex < announcements.length) {
                    setActiveAnnouncement(newIndex)
                  }
                }
              }}
              onTouchStart={() => { if (carouselTimerRef.current) clearInterval(carouselTimerRef.current) }}
              onTouchEnd={() => {
                carouselTimerRef.current = setInterval(() => {
                  setActiveAnnouncement(prev => {
                    const next = (prev + 1) % announcements.length
                    if (carouselRef.current) {
                      const cardWidth = carouselRef.current.children[0]?.getBoundingClientRect().width || 300
                      carouselRef.current.scrollTo({ left: next * cardWidth, behavior: 'smooth' })
                    }
                    return next
                  })
                }, 3000)
              }}
              className="flex overflow-x-auto scrollbar-hide snap-x snap-mandatory"
            >
              {announcements.map((a, index) => (
                <button key={a.id} onClick={() => { setSelectedAnnouncement(a); navigateTo('announcement-detail') }} className="flex-shrink-0 w-full snap-center px-1">
                  <div className={`bg-gradient-to-br ${a.gradient} rounded-2xl overflow-hidden shadow-md active:scale-[0.98] transition-transform`}>
                    <div className="h-44 relative flex items-center justify-center overflow-hidden">
                      {a.imageUrl ? (
                        /* Full-width image mode */
                        <>
                          <img src={a.imageUrl} alt={a.title} className="absolute inset-0 w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
                          <div className="relative z-10 flex items-center gap-3 px-4 w-full">
                            <div className="flex-1 min-w-0">
                              <p className="text-white font-bold text-lg leading-tight drop-shadow-lg">{a.title}</p>
                              <p className="text-white/90 text-sm mt-1 drop-shadow-md">{a.subtitle}</p>
                              <div className="flex items-center gap-1 mt-2">
                                <span className="text-white/60 text-[10px]">{_t('home.tapExplore')}</span>
                                <ChevronRight className="w-3 h-3 text-white/60" />
                              </div>
                            </div>
                          </div>
                        </>
                      ) : (
                        /* Icon mode (original) */
                        <>
                          <div className="absolute inset-0 opacity-10">
                            <div className="absolute top-3 left-6 w-24 h-24 rounded-full border-4 border-white" />
                            <div className="absolute bottom-2 right-8 w-20 h-20 rounded-full border-4 border-white" />
                            <div className="absolute top-10 right-16 w-10 h-10 rounded-full bg-white" />
                            <div className="absolute bottom-4 left-20 w-6 h-6 rounded-full bg-white" />
                          </div>
                          <div className="relative z-10 flex items-center gap-4 px-4">
                            <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center flex-shrink-0">
                              {a.image === 'ssc' && <BookOpen className="w-10 h-10 text-white" />}
                              {a.image === 'banking' && <Building className="w-10 h-10 text-white" />}
                              {a.image === 'leaderboard' && <Trophy className="w-10 h-10 text-white" />}
                              {a.image === 'practice' && <Zap className="w-10 h-10 text-white" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-white font-bold text-lg leading-tight">{a.title}</p>
                              <p className="text-white/80 text-sm mt-1">{a.subtitle}</p>
                              <div className="flex items-center gap-1 mt-2">
                                <span className="text-white/50 text-[10px]">{_t('home.tapExplore')}</span>
                                <ChevronRight className="w-3 h-3 text-white/50" />
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
            <div className="flex items-center justify-center gap-1.5 mt-1">
              {announcements.map((_, i) => (
                <button key={i} onClick={() => {
                  setActiveAnnouncement(i)
                  if (carouselRef.current) {
                    const cardWidth = carouselRef.current.children[0]?.getBoundingClientRect().width || 250
                    carouselRef.current.scrollTo({ left: i * cardWidth, behavior: 'smooth' })
                  }
                }}
                  className={`h-1.5 rounded-full transition-all duration-300 ${i === activeAnnouncement ? 'w-4 bg-orange-500' : 'w-1.5 bg-gray-300'}`}
                />
              ))}
            </div>
          </div>
        </div>
        )}

        <div className="px-4 mt-4 space-y-5">
          {/* Quick Practice - Professional Card */}
          <Card className="border-0 shadow-lg overflow-hidden">
            <div className="bg-gradient-to-r from-orange-500 to-red-500 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-white text-base">{_t('home.quickPractice')}</p>
                    <p className="text-white/70 text-xs mt-0.5">
                      {auth.needsRealAccount && !auth.canGuestUseQuickPractice
                        ? _t('guest.alreadyUsed')
                        : _t('home.quickPracticeSub')}
                    </p>
                  </div>
                </div>
                <Button
                  className={`rounded-xl font-bold shadow-md active:scale-95 transition-all ${
                    auth.needsRealAccount && !auth.canGuestUseQuickPractice
                      ? 'bg-white/30 text-white cursor-not-allowed'
                      : 'bg-white text-orange-600 hover:bg-white/90'
                  }`}
                  onClick={handleQuickPractice}
                >
                  {auth.needsRealAccount && !auth.canGuestUseQuickPractice ? (
                    <><Lock className="w-4 h-4 mr-1" /> {_t('guest.alreadyUsed')}</>
                  ) : (
                    <><Play className="w-4 h-4 mr-1" /> {_t('home.start')}</>
                  )}
                </Button>
              </div>
            </div>
          </Card>

          {/* Exam Categories - Professional Cards */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-lg">{_t('home.examCategories')}</h2>
              <button onClick={() => handleBottomNav('exams')} className="text-orange-600 text-sm font-semibold flex items-center gap-0.5">
                {_t('home.viewAll')} <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {categories.map(cat => {
                const color = getCatColor(cat.slug)
                return (
                  <Card
                    key={cat.id}
                    className="border-0 shadow-md cursor-pointer hover:shadow-xl transition-all active:scale-[0.96] overflow-hidden"
                    onClick={() => { setSelectedCategory(cat); handleBottomNav('exams') }}
                  >
                    <div className={`bg-gradient-to-br ${color.gradient} p-4 pb-5 relative overflow-hidden`}>
                      {cat.imageUrl && (
                        <>
                          <img src={cat.imageUrl} alt={cat.name} className="absolute inset-0 w-full h-full object-cover opacity-30" />
                          <div className={`absolute inset-0 bg-gradient-to-br ${color.gradient} opacity-70`} />
                        </>
                      )}
                      <div className="relative z-10 flex items-center justify-between">
                        <div className="w-12 h-12 rounded-2xl bg-white/25 backdrop-blur-sm flex items-center justify-center shadow-sm overflow-hidden">
                          {cat.imageUrl ? (
                            <img src={cat.imageUrl} alt={cat.name} className="w-12 h-12 object-cover rounded-2xl" />
                          ) : (
                            <div className="text-white">{getCatIcon(cat.slug)}</div>
                          )}
                        </div>
                        <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
                          <ChevronRight className="w-4 h-4 text-white/80" />
                        </div>
                      </div>
                      <p className="font-bold text-white text-sm mt-3 relative z-10">{cat.name}</p>
                      <div className="flex items-center gap-1.5 mt-1.5 relative z-10">
                        <span className="text-[10px] text-white/80 bg-white/20 px-2 py-0.5 rounded-full font-medium backdrop-blur-sm">{cat.exams.length} {_t('home.exams')}</span>
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          </div>

          {/* Popular Exams - Professional List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-lg">{_t('home.popularExams')}</h2>
            </div>
            <div className="space-y-2.5">
              {categories.slice(0, 3).flatMap(cat =>
                cat.exams.slice(0, 2).map(exam => {
                  const color = getCatColor(cat.slug)
                  return (
                    <Card
                      key={exam.id}
                      className="border-0 shadow-md cursor-pointer hover:shadow-lg transition-all active:scale-[0.98] overflow-hidden"
                      onClick={() => openExam(exam, cat)}
                    >
                      <CardContent className="p-0">
                        <div className="flex items-center">
                          {/* Left colored strip */}
                          <div className={`w-1.5 self-stretch bg-gradient-to-b ${color.gradient}`} />
                          <div className="flex items-center gap-3 p-3 flex-1">
                            <div className={`w-12 h-12 rounded-2xl ${color.light} flex items-center justify-center ${color.text} shadow-sm overflow-hidden`}>
                              {exam.imageUrl ? (
                                <img src={exam.imageUrl} alt={exam.name} className="w-12 h-12 object-cover rounded-2xl" />
                              ) : (
                                getCatIcon(cat.slug)
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-sm truncate text-gray-800">{exam.name}</p>
                              <div className="flex items-center gap-3 mt-1">
                                <span className="text-[10px] text-gray-400 flex items-center gap-1 bg-gray-50 px-1.5 py-0.5 rounded-md">
                                  <BookOpen className="w-2.5 h-2.5" /> {exam.totalQuestions} Qs
                                </span>
                                <span className="text-[10px] text-gray-400 flex items-center gap-1 bg-gray-50 px-1.5 py-0.5 rounded-md">
                                  <Clock className="w-2.5 h-2.5" /> {exam.duration}m
                                </span>
                              </div>
                            </div>
                            <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${color.gradient} flex items-center justify-center shadow-sm`}>
                              <ChevronRight className="w-4 h-4 text-white" />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })
              )}
            </div>
          </div>

          {/* Daily Tips Section - Only show when admin has added tips */}
          {dailyTips.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-amber-50 flex items-center justify-center">
                <Star className="w-4 h-4 text-amber-500" />
              </div>
              <h2 className="font-bold text-lg">{_t('home.dailyTips')}</h2>
            </div>
            <div className="space-y-2">
              {dailyTips.map((tip, i) => (
                <Card key={tip.id || i} className="border-0 shadow-md overflow-hidden cursor-pointer active:scale-[0.98] transition-transform" onClick={() => { setSelectedDailyTip(tip); navigateTo('daily-tip-detail') }}>
                  {tip.imageUrl ? (
                    <div className="relative">
                      <img src={tip.imageUrl} alt="" className="w-full h-32 object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <p className="text-sm text-white leading-relaxed drop-shadow-md line-clamp-2">{tip.text}</p>
                      </div>
                      <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <ChevronRight className="w-3.5 h-3.5 text-white" />
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center flex-shrink-0 shadow-sm">
                          <Star className="w-5 h-5 text-white" />
                        </div>
                        <p className="text-sm text-gray-700 leading-relaxed pt-1 flex-1 line-clamp-2">{tip.text}</p>
                        <ChevronRight className="w-4 h-4 text-amber-400 flex-shrink-0 mt-1" />
                      </div>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </div>
          )}

          {/* Upcoming Exams Section - Only show when admin has added exams */}
          {upcomingExams.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                <Calendar className="w-4 h-4 text-blue-500" />
              </div>
              <h2 className="font-bold text-lg">{_t('home.upcomingExams')}</h2>
            </div>
            <div className="space-y-2">
              {upcomingExams.map((exam, i) => (
                <Card key={i} className="border-0 shadow-sm overflow-hidden cursor-pointer active:scale-[0.98] transition-transform" onClick={() => { setSelectedUpcomingExam(exam); navigateTo('upcoming-exam-detail') }}>
                  <CardContent className="p-0">
                    <div className="flex items-center gap-3 p-3">
                      <div className="w-11 h-11 rounded-2xl bg-blue-50 flex items-center justify-center overflow-hidden flex-shrink-0">
                        {exam.imageUrl ? (
                          <img src={exam.imageUrl} alt={exam.name} className="w-11 h-11 object-cover rounded-2xl" />
                        ) : (
                          <Calendar className="w-5 h-5 text-blue-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{exam.name}</p>
                        <p className="text-gray-400 text-xs mt-0.5">{exam.date}</p>
                      </div>
                      <Badge className={`text-[10px] font-bold border-0 ${
                        exam.statusType === 'open' ? 'bg-emerald-100 text-emerald-700' :
                        exam.statusType === 'admit' ? 'bg-amber-100 text-amber-700' :
                        exam.statusType === 'closed' ? 'bg-gray-100 text-gray-600' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {exam.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          )}

          {/* Study Stats / Motivation - Professional */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg bg-green-50 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-green-500" />
              </div>
              <h2 className="font-bold text-lg">{_t('home.yourProgress')}</h2>
            </div>
            {auth.isLoggedIn ? (
              <div className="grid grid-cols-3 gap-2">
                <Card className="border-0 shadow-md overflow-hidden">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-b from-orange-50 to-white p-3 text-center">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-400 to-red-400 flex items-center justify-center mx-auto mb-2 shadow-sm">
                        <Flame className="w-5 h-5 text-white" />
                      </div>
                      <p className="font-extrabold text-2xl text-gray-800">{stats.testsTaken || '-'}</p>
                      <p className="text-gray-400 text-[10px] font-medium mt-0.5">{_t('home.testsDone')}</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-md overflow-hidden">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-b from-emerald-50 to-white p-3 text-center">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-green-400 flex items-center justify-center mx-auto mb-2 shadow-sm">
                        <Target className="w-5 h-5 text-white" />
                      </div>
                      <p className="font-extrabold text-2xl text-gray-800">{stats.avgScore ? `${stats.avgScore}%` : '-'}</p>
                      <p className="text-gray-400 text-[10px] font-medium mt-0.5">{_t('home.accuracy')}</p>
                    </div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-md overflow-hidden">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-b from-blue-50 to-white p-3 text-center">
                      <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-400 to-indigo-400 flex items-center justify-center mx-auto mb-2 shadow-sm">
                        <Award className="w-5 h-5 text-white" />
                      </div>
                      <p className="font-extrabold text-2xl text-gray-800">{stats.bestRank ? `#${stats.bestRank}` : '-'}</p>
                      <p className="text-gray-400 text-[10px] font-medium mt-0.5">{_t('home.bestRank')}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="border-0 shadow-md overflow-hidden">
                <CardContent className="p-0">
                  <div className="bg-gradient-to-r from-orange-50 via-red-50 to-rose-50 p-5 text-center">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-400 to-red-400 flex items-center justify-center mx-auto mb-3 shadow-md">
                      <TrendingUp className="w-7 h-7 text-white" />
                    </div>
                    <p className="font-bold text-gray-800">{_t('home.loginTrack')}</p>
                    <p className="text-gray-500 text-xs mt-1 mb-3">{_t('home.loginTrackSub')}</p>
                    <Button className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-bold shadow-md active:scale-95 transition-all" onClick={() => setShowLoginModal(true)}>
                      {_t('home.loginNow')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    )
  }

  // ===== RENDER: Exams Page =====
  function renderExams() {
    return (
      <div className="pb-20">
        <div className="bg-gradient-to-r from-orange-500 to-red-500 px-4 pt-[calc(env(safe-area-inset-top,0px)+3rem)] pb-6 rounded-b-3xl">
          <div className="flex items-center gap-3 mb-4">
            <button onClick={goBack} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-xl font-bold">{_t('exams.allExams')}</h1>
          </div>
        </div>

        <div className="px-4 mt-4 space-y-6">
          {categories.map(cat => {
            const color = getCatColor(cat.slug)
            return (
              <div key={cat.id}>
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-8 h-8 rounded-lg ${color.light} flex items-center justify-center ${color.text} overflow-hidden`}>
                    {cat.imageUrl ? (
                      <img src={cat.imageUrl} alt={cat.name} className="w-8 h-8 object-cover rounded-lg" />
                    ) : (
                      getCatIcon(cat.slug)
                    )}
                  </div>
                  <h2 className="font-bold text-base">{cat.name}</h2>
                  <Badge variant="secondary" className="text-xs">{cat.exams.length}</Badge>
                </div>
                <div className="space-y-2">
                  {cat.exams.map(exam => (
                    <Card
                      key={exam.id}
                      className="border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => openExam(exam, cat)}
                    >
                      <CardContent className="p-3 flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl ${color.light} flex items-center justify-center ${color.text} shadow-sm overflow-hidden flex-shrink-0`}>
                          {exam.imageUrl ? (
                            <img src={exam.imageUrl} alt={exam.name} className="w-10 h-10 object-cover rounded-xl" />
                          ) : (
                            <BookOpen className="w-5 h-5" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{exam.name}</p>
                          <p className="text-gray-400 text-xs">{exam.testCount} {_t('exams.tests')} · {exam.totalQuestions} {_t('tests.Qs')} · {exam.duration} {_t('tests.min')}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Badge className={`bg-gradient-to-r ${color.gradient} text-white text-xs border-0`}>
                            {exam.testCount} {_t('exams.tests')}
                          </Badge>
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  // ===== RENDER: Tests Page =====
  function renderTests() {
    if (!selectedExam || !selectedCategory) return null
    const color = getCatColor(selectedCategory.slug)
    return (
      <div className="pb-20">
        <div className={`bg-gradient-to-r ${color.gradient} px-4 pt-[calc(env(safe-area-inset-top,0px)+3rem)] pb-6 rounded-b-3xl`}>
          <div className="flex items-center gap-3 mb-2">
            <button onClick={goBack} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <div className="flex-1 min-w-0">
              <h1 className="text-white text-lg font-bold truncate">{selectedExam.name}</h1>
              <div className="flex items-center gap-2">
                <p className="text-white/70 text-xs">{selectedCategory.name}</p>
                {currentTestMode === 'practice' && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-200 bg-white/15 px-2 py-0.5 rounded-full">
                    <Zap className="w-2.5 h-2.5" /> Practice
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-1 text-white/80 text-xs">
              <BookOpen className="w-3 h-3" /> {selectedExam.totalQuestions} {_t('tests.Qs')}
            </div>
            <div className="flex items-center gap-1 text-white/80 text-xs">
              <Clock className="w-3 h-3" /> {selectedExam.duration} {_t('tests.min')}
            </div>
            <div className="flex items-center gap-1 text-white/80 text-xs">
              <FileText className="w-3 h-3" /> {examTests.length} {_t('exams.tests')}
            </div>
          </div>
        </div>

        <div className="px-4 mt-4">
          <h2 className="font-bold text-base mb-3">{_t('tests.available')}</h2>
          <div className="space-y-3">
            {examTests.map(test => (
              <Card key={test.id} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0 mr-2">
                      <p className="font-semibold text-sm">{test.title}</p>
                      <p className="text-gray-400 text-xs mt-1">{test.description}</p>
                    </div>
                    {test.isFree && <Badge className="bg-emerald-100 text-emerald-700 text-xs border-0">{_t('tests.free')}</Badge>}
                  </div>
                  <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
                    <span className="flex items-center gap-1"><BookOpen className="w-3 h-3" /> {test.totalQuestions} {_t('tests.Qs')}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {test.duration} {_t('tests.min')}</span>
                    <span className="flex items-center gap-1"><Target className="w-3 h-3" /> {test.difficulty}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <Button
                      size="sm"
                      className={`bg-gradient-to-r ${color.gradient} text-white rounded-xl flex-1`}
                      onClick={() => openTestInfo(test)}
                    >
                      <Play className="w-4 h-4 mr-1" /> {_t('tests.startTest')}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="rounded-xl"
                      onClick={() => openLeaderboard(test.id)}
                    >
                      <Trophy className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // ===== RENDER: Test Info Page =====
  function renderTestInfo() {
    if (!selectedTest) return null
    const cat = selectedCategory || categories[0]
    const color = getCatColor(cat.slug)

    return (
      <div className="pb-24">
        <div className={`bg-gradient-to-r ${color.gradient} px-4 pt-[calc(env(safe-area-inset-top,0px)+3rem)] pb-6 rounded-b-3xl`}>
          <div className="flex items-center gap-3 mb-3">
            <button onClick={goBack} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-lg font-bold flex-1 truncate">{_t('testInfo.details')}</h1>
          </div>
          <h2 className="text-white font-semibold">{selectedTest.title}</h2>
          <p className="text-white/70 text-sm mt-1">{selectedExam?.name || selectedCategory?.name || ''}</p>
        </div>

        <div className="px-4 mt-4 space-y-4">
          {/* Test Information - Professional Card */}
          <Card className="border-0 shadow-md overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-500 px-4 py-3">
              <h3 className="text-white font-bold flex items-center gap-2">
                <FileText className="w-5 h-5" />
                {_t('testInfo.information')}
              </h3>
            </div>
            <CardContent className="p-0">
              <div className="grid grid-cols-2 gap-0">
                <div className="p-4 border-b border-r border-gray-100">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
                      <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                    </div>
                    <span className="text-[11px] text-gray-400 uppercase tracking-wider font-medium">{_t('testInfo.totalQ')}</span>
                  </div>
                  <p className="text-xl font-bold text-gray-800 ml-9">{selectedTest.totalQuestions || selectedTest.questions?.length || 0}</p>
                </div>
                <div className="p-4 border-b border-gray-100">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 rounded-lg bg-violet-50 flex items-center justify-center">
                      <Clock className="w-3.5 h-3.5 text-violet-600" />
                    </div>
                    <span className="text-[11px] text-gray-400 uppercase tracking-wider font-medium">{_t('testInfo.duration')}</span>
                  </div>
                  <p className="text-xl font-bold text-gray-800 ml-9">{selectedTest.duration || 0} {_t('testInfo.minutes')}</p>
                </div>
                <div className="p-4 border-r border-gray-100">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 rounded-lg bg-amber-50 flex items-center justify-center">
                      <Target className="w-3.5 h-3.5 text-amber-600" />
                    </div>
                    <span className="text-[11px] text-gray-400 uppercase tracking-wider font-medium">{_t('testInfo.difficulty')}</span>
                  </div>
                  <div className="ml-9">
                    <Badge className={`${selectedTest.difficulty === 'Easy' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : selectedTest.difficulty === 'Medium' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-red-100 text-red-700 border-red-200'} border text-xs font-bold`}>
                      {selectedTest.difficulty}
                    </Badge>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7 h-7 rounded-lg bg-orange-50 flex items-center justify-center">
                      <Award className="w-3.5 h-3.5 text-orange-600" />
                    </div>
                    <span className="text-[11px] text-gray-400 uppercase tracking-wider font-medium">{_t('testInfo.maxScore')}</span>
                  </div>
                  <p className="text-xl font-bold text-orange-600 ml-9">{(selectedTest.totalQuestions || selectedTest.questions?.length || 0) * (selectedTest.correctMarks || 1)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Marking Scheme - Professional Card */}
          <Card className="border-0 shadow-md overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-3">
              <h3 className="text-white font-bold flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Marking Scheme
              </h3>
            </div>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-emerald-500 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">{_t('testInfo.correctAns')}</p>
                    <p className="font-semibold text-gray-800">{_t('testInfo.correctAns')}</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-emerald-600">+{selectedTest.correctMarks || 1}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-red-50 rounded-xl border border-red-100">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-red-500 flex items-center justify-center">
                    <XCircle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">{_t('testInfo.wrongAns')}</p>
                    <p className="font-semibold text-gray-800">{_t('testInfo.wrongAns')}</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-red-600">-{selectedTest.wrongMarks || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gray-400 flex items-center justify-center">
                    <SkipForward className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">{_t('testInfo.skipped')}</p>
                    <p className="font-semibold text-gray-800">{_t('testInfo.skipped')}</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-gray-400">{selectedTest.skipMarks}</span>
              </div>
            </CardContent>
          </Card>

          {/* Max Score Highlight Card */}
          <Card className="border-0 shadow-md bg-gradient-to-r from-orange-500 to-red-500 overflow-hidden">
            <CardContent className="p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-white/80 text-xs font-medium uppercase tracking-wider">{_t('testInfo.maxScore')}</p>
                  <p className="text-white font-bold text-2xl">{(selectedTest.totalQuestions || selectedTest.questions?.length || 0) * (selectedTest.correctMarks || 1)} {_t('testInfo.marks')}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-white/70 text-[10px] uppercase tracking-wider">{_t('testInfo.totalQ')}</p>
                <p className="text-white font-bold text-lg">{selectedTest.totalQuestions || selectedTest.questions?.length || 0}</p>
              </div>
            </CardContent>
          </Card>

          {/* Practice Mode Badge */}
          {currentTestMode === 'practice' && (
            <Card className="border-0 shadow-md bg-gradient-to-r from-amber-500 to-orange-500 overflow-hidden">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-white font-bold text-sm">Practice Mode</p>
                  <p className="text-white/70 text-xs">No negative marking · Learn at your pace</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Start Button */}
          <Button
            className="w-full h-14 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-2xl text-lg font-bold shadow-lg shadow-orange-200 hover:shadow-xl hover:shadow-orange-300 transition-all active:scale-[0.98]"
            onClick={() => startTest(selectedTest, currentTestMode)}
          >
            <Play className="w-6 h-6 mr-2" /> {currentTestMode === 'practice' ? 'Start Practice' : _t('testInfo.startNow')}
          </Button>
        </div>
      </div>
    )
  }

  // ===== RENDER: Test Taking =====
  function renderTestTaking() {
    if (!selectedTest) return null
    const questions = selectedTest.questions || []
    const question = questions[currentQuestionIndex]

    // Show helpful message if no questions loaded
    if (questions.length === 0) {
      return (
        <div className="min-h-screen min-h-dvh bg-slate-50 flex flex-col items-center justify-center p-6">
          <div className="bg-white rounded-2xl shadow-lg p-8 max-w-sm w-full text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-100 flex items-center justify-center">
              <BookOpen className="w-8 h-8 text-amber-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-800 mb-2">No Questions Found</h2>
            <p className="text-sm text-gray-500 mb-4">
              This test has no questions yet. The database may need to be seeded.
            </p>
            <p className="text-xs text-gray-400 mb-4">
              Test: {selectedTest.title} (ID: {selectedTest.id?.substring(0, 8)}...)
            </p>
            {isFirestore() ? (
              <p className="text-xs text-amber-600 font-medium">
                Go to Admin Panel → Dashboard → Click &quot;Seed Now&quot; to load sample questions.
              </p>
            ) : (
              <p className="text-xs text-amber-600 font-medium">
                Using local data. Check if tests have questions in local-data.ts
              </p>
            )}
            <button
              onClick={() => navigateTo('exams')}
              className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600 transition-colors"
            >
              Go Back
            </button>
          </div>
        </div>
      )
    }
    if (!question) return null

    const totalAnswered = Object.keys(answers).length
    const totalMarked = markedForReview.size
    const progressPercent = (totalAnswered / questions.length) * 100

    const optionLabels: Record<string, string> = { A: question.optionA, B: question.optionB, C: question.optionC, D: question.optionD }
    const optionLetters = ['A', 'B', 'C', 'D']

    return (
      <div className="min-h-screen min-h-dvh bg-slate-50 flex flex-col secure-content" style={{ userSelect: 'none', WebkitUserSelect: 'none' }} onContextMenu={e => e.preventDefault()}>
        {/* === Professional Exam Header === */}
        <div className="bg-white shadow-sm">
          {/* Top Bar: Back | Test Name | Timer */}
          <div className="px-3 pt-[calc(env(safe-area-inset-top,0px)+0.5rem)] pb-2 flex items-center justify-between gap-2">
            <button
              onClick={() => setShowBackConfirm(true)}
              className="w-9 h-9 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors flex-shrink-0"
            >
              <ArrowLeft className="w-4 h-4 text-gray-700" />
            </button>
            <div className="flex-1 text-center min-w-0">
              <h1 className="text-sm font-bold text-gray-800 truncate">{selectedTest.title}</h1>
              {currentTestMode === 'practice' && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full mt-0.5">
                  <Zap className="w-2.5 h-2.5" /> Practice Mode
                </span>
              )}
            </div>
            {/* Prominent Timer Box */}
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-mono font-bold text-sm flex-shrink-0 ${
              timeLeft < 60 ? 'bg-red-100 text-red-700 ring-2 ring-red-300' :
              timeLeft < 300 ? 'bg-amber-100 text-amber-700 ring-2 ring-amber-300' :
              'bg-orange-100 text-orange-700'
            }`}>
              <Timer className="w-3.5 h-3.5" />
              <span>{formatTime(timeLeft)}</span>
            </div>
          </div>

          {/* Info Bar: Question X of Y | Answered: A | Marked: M */}
          <div className="px-3 pb-2 flex items-center justify-between text-xs">
            <span className="text-gray-600 font-semibold">
              {_t('testTaking.questionNav').includes('Navigator') ? 'Question' : _t('testTaking.questionNav').split(' ')[0]} {currentQuestionIndex + 1} {_t('testTaking.of')} {questions.length}
            </span>
            <div className="flex items-center gap-3 text-gray-500">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-orange-500" />
                {_t('testTaking.answered')}: <strong className="text-gray-700">{totalAnswered}</strong>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                {_t('testTaking.marked')}: <strong className="text-gray-700">{totalMarked}</strong>
              </span>
            </div>
          </div>

          {/* Thin Progress Bar */}
          <div className="h-1 bg-gray-100">
            <div
              className="h-full bg-gradient-to-r from-orange-400 to-orange-600 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* === Question Section === */}
        <ScrollArea className="flex-1">
          <div className="p-4 pb-2">
            {/* Question Card with Badge */}
            <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 relative overflow-hidden">
              {/* Watermark for copy protection */}
              <div className="watermark-overlay" />
              <div className="flex items-start gap-3">
                {/* Question Number Badge */}
                <div className="flex flex-col items-center gap-1 flex-shrink-0">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-extrabold shadow-sm ${
                    markedForReview.has(question.id)
                      ? 'bg-amber-500 text-white ring-2 ring-amber-300'
                      : 'bg-orange-500 text-white'
                  }`}>
                    {currentQuestionIndex + 1}
                  </div>
                  {markedForReview.has(question.id) && (
                    <div className="flex items-center gap-0.5 text-[9px] text-amber-600 font-semibold">
                      <BookMarked className="w-2.5 h-2.5" />
                    </div>
                  )}
                </div>
                {/* Question Text */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Q.{currentQuestionIndex + 1}</span>
                    {question.subject && (
                      <Badge variant="secondary" className="text-[10px] px-2 py-0 h-5 bg-slate-100 text-slate-600">{question.subject}</Badge>
                    )}
                    {markedForReview.has(question.id) && (
                      <Badge className="text-[10px] px-2 py-0 h-5 bg-amber-100 text-amber-700 border-0">
                        {_t('testTaking.markedReview')}
                      </Badge>
                    )}
                  </div>
                  <p className="text-[15px] font-medium leading-relaxed text-gray-800">{question.questionText}</p>
                </div>
              </div>
            </div>
          </div>

          {/* === Options Section (OMR Style) === */}
          <div className="px-4 pb-4 space-y-2.5">
            {optionLetters.map(letter => {
              const isSelected = answers[question.id] === letter
              const isCorrect = question.correctAnswer === letter
              // In practice mode, show correct/incorrect after answering
              const showFeedback = currentTestMode === 'practice' && isSelected
              return (
                <button
                  key={letter}
                  onClick={() => selectAnswer(question.id, letter)}
                  className={`w-full text-left px-4 py-3.5 rounded-lg border-2 transition-all duration-150 active:scale-[0.99] ${
                    showFeedback && isCorrect
                      ? 'border-emerald-500 bg-emerald-50 shadow-sm ring-1 ring-emerald-200'
                      : showFeedback && !isCorrect
                      ? 'border-red-400 bg-red-50 shadow-sm ring-1 ring-red-200'
                      : isSelected
                      ? 'border-orange-500 bg-orange-50 shadow-sm ring-1 ring-orange-200'
                      : currentTestMode === 'practice' && answers[question.id] && isCorrect
                      ? 'border-emerald-300 bg-emerald-50/50' // Show correct answer in practice mode when wrong selected
                      : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* Radio-style circle */}
                    <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-sm font-bold flex-shrink-0 transition-all ${
                      showFeedback && isCorrect
                        ? 'border-emerald-500 bg-emerald-500 text-white shadow-sm'
                        : showFeedback && !isCorrect
                        ? 'border-red-400 bg-red-400 text-white shadow-sm'
                        : isSelected
                        ? 'border-orange-500 bg-orange-500 text-white shadow-sm'
                        : currentTestMode === 'practice' && answers[question.id] && isCorrect
                        ? 'border-emerald-400 bg-emerald-100 text-emerald-600'
                        : 'border-gray-300 bg-white text-gray-500'
                    }`}>
                      {showFeedback && isCorrect ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : showFeedback && !isCorrect ? (
                        <XCircle className="w-4 h-4" />
                      ) : isSelected ? (
                        <span className="text-xs">●</span>
                      ) : (
                        letter
                      )}
                    </div>
                    <span className={`text-sm leading-relaxed ${
                      showFeedback && isCorrect ? 'text-emerald-800 font-semibold'
                      : showFeedback && !isCorrect ? 'text-red-700 font-medium line-through'
                      : isSelected ? 'text-gray-900 font-medium' : 'text-gray-700'
                    }`}>
                      <span className={`font-semibold mr-1.5 ${
                        showFeedback && isCorrect ? 'text-emerald-600' : showFeedback && !isCorrect ? 'text-red-500' : 'text-gray-500'
                      }`}>{letter}.</span>
                      {optionLabels[letter]}
                    </span>
                    {showFeedback && isCorrect && <span className="ml-auto text-emerald-600 text-xs font-bold">✓ Correct</span>}
                    {showFeedback && !isCorrect && <span className="ml-auto text-red-500 text-xs font-bold">✗ Wrong</span>}
                  </div>
                </button>
              )
            })}
            {/* In practice mode, show explanation after answering */}
            {currentTestMode === 'practice' && answers[question.id] && question.explanation && (
              <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-xl">
                <p className="text-xs font-bold text-blue-700 mb-1">💡 Explanation</p>
                <p className="text-xs text-blue-800 leading-relaxed">{question.explanation}</p>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* === Bottom Action Bar (Professional Compact) === */}
        <div className="bg-white border-t border-gray-200 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
          {/* Row 1: Action Buttons - Equal Width */}
          <div className="px-2 pt-2 pb-1 grid grid-cols-4 gap-1.5">
            <Button
              size="sm"
              className={`rounded-lg h-8 text-xs font-semibold border-0 transition-all active:scale-95 ${
                bookmarkedQs.includes(question.id)
                  ? 'bg-amber-500 text-white hover:bg-amber-600'
                  : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
              }`}
              onClick={() => toggleBookmark(question.id)}
            >
              <BookmarkPlus className="w-3.5 h-3.5 mr-0.5" />
              {bookmarkedQs.includes(question.id) ? _t('testTaking.bookmarked') : _t('testTaking.bookmark')}
            </Button>
            <Button
              size="sm"
              className={`rounded-lg h-8 text-xs font-semibold border-0 transition-all active:scale-95 ${
                markedForReview.has(question.id)
                  ? 'bg-purple-600 text-white hover:bg-purple-700'
                  : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
              }`}
              onClick={() => toggleReview(question.id)}
            >
              <BookMarked className="w-3.5 h-3.5 mr-0.5" />
              {markedForReview.has(question.id) ? _t('testTaking.unmark') : _t('testTaking.mark')}
            </Button>
            <Button
              size="sm"
              className="rounded-lg h-8 text-xs font-semibold bg-red-50 text-red-600 border-0 hover:bg-red-100 transition-all active:scale-95"
              onClick={() => clearAnswer(question.id)}
            >
              <RefreshCw className="w-3.5 h-3.5 mr-0.5" /> {_t('testTaking.clear')}
            </Button>
            <Button
              size="sm"
              className="rounded-lg h-8 text-xs font-semibold bg-sky-50 text-sky-700 border-0 hover:bg-sky-100 transition-all active:scale-95"
              onClick={() => {
                if (currentQuestionIndex < questions.length - 1) {
                  setCurrentQuestionIndex(prev => prev + 1)
                }
              }}
            >
              <SkipForward className="w-3.5 h-3.5 mr-0.5" /> {_t('testTaking.skip')}
            </Button>
          </div>
          {/* Row 2: Previous (Left) | Submit & Navigator (Center) | Save & Next (Right) */}
          <div className="px-2 pb-2 flex items-center gap-2">
            {/* Left: Previous */}
            <Button
              size="sm"
              className="rounded-lg flex-1 h-9 font-bold text-sm bg-gradient-to-r from-blue-500 to-indigo-600 text-white border-0 hover:from-blue-600 hover:to-indigo-700 transition-all active:scale-95 disabled:opacity-40"
              disabled={currentQuestionIndex === 0}
              onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
            >
              <ChevronLeft className="w-4 h-4 mr-1" /> {_t('testTaking.previous')}
            </Button>
            {/* Center: Submit Test & Question Navigator */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => setShowQuestionNav(true)}
                className="h-9 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-gray-600 text-xs font-semibold transition-colors flex items-center gap-1"
              >
                <BookMarked className="w-3.5 h-3.5" />
                {questions.length}
              </button>
              <Button
                size="sm"
                className="rounded-lg h-9 px-4 font-bold text-sm bg-gradient-to-r from-red-500 to-rose-600 text-white border-0 hover:from-red-600 hover:to-rose-700 transition-all active:scale-95 flex-shrink-0"
                onClick={handleFinishTest}
              >
                {_t('testTaking.submit')}
              </Button>
            </div>
            {/* Right: Save & Next */}
            <Button
              size="sm"
              className="rounded-lg flex-1 h-9 font-bold text-sm bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 hover:from-green-600 hover:to-emerald-700 transition-all active:scale-95 disabled:opacity-40"
              disabled={currentQuestionIndex === questions.length - 1}
              onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
            >
              {_t('testTaking.saveNext')} <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>

        {/* Question Navigation Panel */}
        {showQuestionNav && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center" onClick={() => setShowQuestionNav(false)}>
            <div className="bg-white rounded-t-3xl w-full max-h-[70vh] p-6" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">{_t('testTaking.questionNav')}</h3>
                <button onClick={() => setShowQuestionNav(false)} className="text-gray-400 text-2xl">&times;</button>
              </div>
              <div className="flex items-center gap-4 mb-4 text-xs">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-orange-500" /> {_t('testTaking.answered')}</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-gray-200" /> {_t('testTaking.unanswered')}</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-amber-400" /> {_t('testTaking.marked')}</span>
              </div>
              <div className="grid grid-cols-5 gap-2 max-h-60 overflow-y-auto">
                {questions.map((q, i) => {
                  const isAnswered = !!answers[q.id]
                  const isMarked = markedForReview.has(q.id)
                  const isCurrent = i === currentQuestionIndex
                  let bgClass = 'bg-gray-200 text-gray-600'
                  if (isCurrent) bgClass = 'ring-2 ring-orange-500 bg-white'
                  if (isAnswered) bgClass = 'bg-orange-500 text-white'
                  if (isMarked && !isAnswered) bgClass = 'bg-amber-400 text-white'
                  if (isMarked && isAnswered) bgClass = 'bg-orange-500 text-white ring-2 ring-amber-400'

                  return (
                    <button
                      key={q.id}
                      onClick={() => { setCurrentQuestionIndex(i); setShowQuestionNav(false) }}
                      className={`w-full aspect-square rounded-xl flex items-center justify-center font-bold text-sm ${bgClass}`}
                    >
                      {i + 1}
                    </button>
                  )
                })}
              </div>
              <Button
                className="w-full mt-4 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl"
                onClick={handleFinishTest}
              >
                {_t('testTaking.submit')}
              </Button>
            </div>
          </div>
        )}

        {/* Back Confirmation - Professional Dialog */}
        {showBackConfirm && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-5">
            <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden animate-scale-in">
              <div className="p-6 pb-4 text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-100 to-red-50 flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-red-500" />
                </div>
                <h3 className="font-bold text-xl text-gray-900">{_t('testTaking.leaveTest')}</h3>
                <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                  {_t('testTaking.leaveMsg')}
                </p>
              </div>
              <div className="px-6 pb-6 space-y-2.5">
                <Button
                  className="w-full h-11 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-semibold text-sm"
                  onClick={() => setShowBackConfirm(false)}
                >
                  {_t('testTaking.noContinue')}
                </Button>
                <Button
                  variant="outline"
                  className="w-full h-11 rounded-xl border-gray-200 text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 font-semibold text-sm"
                  onClick={() => {
                    setShowBackConfirm(false)
                    if (timerRef.current) clearInterval(timerRef.current)
                    setTestActive(false)
                    goBack()
                  }}
                >
                  {_t('testTaking.yesLeave')}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  // ===== Share as PDF =====
  async function shareAsPDF() {
    if (!lastResult || !selectedTest) return
    if (pdfSharing) return // prevent double-tap
    setPdfSharing(true)
    const questions = selectedTest.questions
    const percentage = Math.round((lastResult.score / lastResult.maxScore) * 100)
    const userName = auth.isLoggedIn ? (auth.user?.displayName || auth.user?.email?.split('@')[0] || 'Student') : 'Student'

    try {
      const doc = new jsPDF()
      let y = 15

      // Orange header bar
      doc.setFillColor(234, 88, 12)
      doc.rect(0, 0, 210, 38, 'F')
      doc.setTextColor(255, 255, 255)
      doc.setFontSize(18)
      doc.setFont('helvetica', 'bold')
      doc.text('MockMaster - Exam Result', 105, 16, { align: 'center' })
      doc.setFontSize(10)
      doc.setFont('helvetica', 'normal')
      doc.text(selectedTest.title, 105, 24, { align: 'center' })
      doc.text(`Student: ${userName}`, 105, 31, { align: 'center' })

      y = 46

      // Score
      doc.setTextColor(50, 50, 50)
      doc.setFontSize(14)
      doc.setFont('helvetica', 'bold')
      doc.text(`Score: ${lastResult.score} / ${lastResult.maxScore}  (${percentage}%)`, 15, y)
      y += 7
      doc.setFontSize(9)
      doc.setFont('helvetica', 'normal')
      doc.setTextColor(100, 100, 100)
      doc.text(`Correct: ${lastResult.correctCount}  |  Wrong: ${lastResult.wrongCount}  |  Skipped: ${lastResult.skippedCount}  |  Time: ${formatTime(lastResult.timeTaken)}`, 15, y)
      y += 9

      // Answer Key
      doc.setTextColor(50, 50, 50)
      doc.setFontSize(12)
      doc.setFont('helvetica', 'bold')
      doc.text('Answer Key', 15, y)
      y += 7

      doc.setFontSize(8)
      for (let i = 0; i < questions.length; i++) {
        const q = questions[i]
        const userAnswer = lastResult.answers[q.id]
        const isCorrect = userAnswer === q.correctAnswer
        const isSkipped = !userAnswer

        if (y > 272) { doc.addPage(); y = 15 }

        if (isCorrect) { doc.setTextColor(16, 185, 129); doc.text('[OK]', 15, y) }
        else if (isSkipped) { doc.setTextColor(156, 163, 175); doc.text('[--]', 15, y) }
        else { doc.setTextColor(239, 68, 68); doc.text('[X]', 15, y) }

        doc.setTextColor(50, 50, 50)
        doc.setFont('helvetica', 'bold')
        const qText = `${i + 1}. ${q.questionText.substring(0, 85)}${q.questionText.length > 85 ? '...' : ''}`
        doc.text(qText, 27, y)
        doc.setFont('helvetica', 'normal')
        y += 4.5

        const opts = [{ l: 'A', t: q.optionA }, { l: 'B', t: q.optionB }, { l: 'C', t: q.optionC }, { l: 'D', t: q.optionD }]
        for (const o of opts) {
          if (y > 275) { doc.addPage(); y = 15 }
          const isUA = userAnswer === o.l
          const isCO = q.correctAnswer === o.l
          let pfx = '   '
          if (isCO) { doc.setTextColor(16, 185, 129); pfx = ' > ' }
          else if (isUA && !isCorrect) { doc.setTextColor(239, 68, 68); pfx = ' X ' }
          else { doc.setTextColor(150, 150, 150) }
          const oTxt = `${pfx}${o.l}. ${o.t.substring(0, 65)}${o.t.length > 65 ? '...' : ''}${isUA ? ' (You)' : ''}${isCO ? ' [Correct]' : ''}`
          doc.text(oTxt, 27, y)
          y += 4
        }

        if (q.explanation) {
          if (y > 270) { doc.addPage(); y = 15 }
          doc.setTextColor(59, 130, 246)
          doc.text(`   Exp: ${q.explanation.substring(0, 85)}${q.explanation.length > 85 ? '...' : ''}`, 27, y)
          y += 4.5
        }
        y += 2.5
      }

      // Footer
      const pages = doc.getNumberOfPages()
      for (let p = 1; p <= pages; p++) {
        doc.setPage(p)
        doc.setTextColor(180, 180, 180)
        doc.setFontSize(7)
        doc.text('Generated by MockMaster', 105, 290, { align: 'center' })
      }

      // Get base64 from jsPDF output
      const pdfBase64 = doc.output('datauristring').split(',')[1]

      // Try native share (Capacitor/Android)
      let nativeShareWorked = false
      try {
        const fileName = `MockMaster_Result_${Date.now()}.pdf`
        const fileResult = await Filesystem.writeFile({
          path: fileName, data: pdfBase64, directory: Directory.Cache,
        })
        await Share.share({
          title: 'MockMaster Exam Result',
          text: `I scored ${percentage}% on ${selectedTest.title}!`,
          url: fileResult.uri,
        })
        nativeShareWorked = true
      } catch (shareErr: any) {
        // User cancelled share or share failed - fall through to download
        if (shareErr?.message?.includes('cancelled') || shareErr?.message?.includes('canceled')) {
          nativeShareWorked = true // user cancelled, not an error
        }
      }

      // Fallback: download PDF as blob
      if (!nativeShareWorked) {
        try {
          const pdfBlob = doc.output('blob')
          const url = URL.createObjectURL(pdfBlob)
          const a = document.createElement('a')
          a.href = url
          a.download = `MockMaster_Result_${Date.now()}.pdf`
          document.body.appendChild(a)
          a.click()
          document.body.removeChild(a)
          URL.revokeObjectURL(url)
        } catch (dlErr) {
          console.error('Download fallback failed:', dlErr)
        }
      }
    } catch (err) {
      console.error('PDF generation error:', err)
    } finally {
      setPdfSharing(false)
    }
  }

  // ===== RENDER: Results Page =====
  function renderResults() {
    if (!lastResult || !selectedTest) return null
    const percentage = Math.round((lastResult.score / lastResult.maxScore) * 100)
    const questions = selectedTest.questions

    return (
      <div className="pb-20 secure-content" style={{ userSelect: 'none', WebkitUserSelect: 'none' }} onContextMenu={e => e.preventDefault()}>
        <div className="bg-gradient-to-r from-orange-500 to-red-500 px-4 pt-[calc(env(safe-area-inset-top,0px)+0.5rem)] pb-8 rounded-b-3xl text-center relative">
          {/* Back Button */}
          <button
            onClick={goBack}
            className="absolute left-4 top-[calc(env(safe-area-inset-top,0px)+0.5rem)] w-9 h-9 rounded-lg bg-white/15 backdrop-blur flex items-center justify-center active:bg-white/25 transition-colors"
            style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
          >
            <ArrowLeft className="w-4 h-4 text-white" />
          </button>
          <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4 mt-6">
            {percentage >= 60 ? (
              <Trophy className="w-10 h-10 text-yellow-300" />
            ) : percentage >= 30 ? (
              <Target className="w-10 h-10 text-white" />
            ) : (
              <BookOpen className="w-10 h-10 text-white" />
            )}
          </div>
          <h1 className="text-white text-2xl font-bold">
            {percentage >= 60 ? _t('results.greatJob') : percentage >= 30 ? _t('results.keepPracticing') : _t('results.keepGoing')}
          </h1>
          <p className="text-white/70 text-sm mt-1">{selectedTest.title}</p>
        </div>

        <div className="px-4 -mt-4 space-y-4">
          {/* Score Card */}
          <Card className="border-0 shadow-md">
            <CardContent className="p-6 text-center">
              <div className="text-4xl font-bold text-orange-600">{lastResult.score}<span className="text-lg text-gray-400">/{lastResult.maxScore}</span></div>
              <Progress value={Math.max(0, percentage)} className="mt-3 h-2" />
              <p className="text-gray-500 text-sm mt-2">{percentage}% {_t('results.score')}</p>
            </CardContent>
          </Card>

          {/* Breakdown */}
          <div className="grid grid-cols-3 gap-3">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
                <p className="font-bold text-lg text-emerald-600 mt-1">{lastResult.correctCount}</p>
                <p className="text-gray-400 text-xs">{_t('results.correct')}</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <XCircle className="w-6 h-6 text-red-500 mx-auto" />
                <p className="font-bold text-lg text-red-600 mt-1">{lastResult.wrongCount}</p>
                <p className="text-gray-400 text-xs">{_t('results.wrong')}</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <SkipForward className="w-6 h-6 text-gray-400 mx-auto" />
                <p className="font-bold text-lg text-gray-500 mt-1">{lastResult.skippedCount}</p>
                <p className="text-gray-400 text-xs">{_t('results.skipped')}</p>
              </CardContent>
            </Card>
          </div>

          {/* Time Taken */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-3 flex items-center gap-3">
              <Clock className="w-5 h-5 text-orange-500" />
              <span className="text-gray-500 text-sm">{_t('results.timeTaken')}</span>
              <span className="font-bold ml-auto">{formatTime(lastResult.timeTaken)}</span>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1 rounded-xl"
              onClick={() => openLeaderboard(lastResult.testId)}
            >
              <Trophy className="w-4 h-4 mr-2" /> {_t('results.leaderboard')}
            </Button>
            <Button
              className="flex-1 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white"
              onClick={() => {
                if (selectedTest) startTest(selectedTest)
              }}
            >
              <RefreshCw className="w-4 h-4 mr-2" /> {_t('results.retry')}
            </Button>
          </div>

          {/* Answer Key - Collapsible */}
          <div>
            <button
              onClick={() => setShowAnswerKey(!showAnswerKey)}
              className="w-full flex items-center justify-between py-3 px-1"
              style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
            >
              <h2 className="font-bold text-lg">{_t('results.answerKey')}</h2>
              <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform duration-200 ${showAnswerKey ? 'rotate-180' : ''}`} />
            </button>
            {showAnswerKey && (
            <div className="space-y-3">
              {questions.map((q, i) => {
                const userAnswer = lastResult.answers[q.id]
                const isCorrect = userAnswer === q.correctAnswer
                const isSkipped = !userAnswer

                return (
                  <Card key={q.id} className="border-0 shadow-sm relative overflow-hidden secure-content" onContextMenu={e => e.preventDefault()}>
                    {/* Watermark for copy protection */}
                    <div className="watermark-overlay" />
                    <CardContent className="p-4 relative z-10">
                      <div className="flex items-start gap-2 mb-2">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                          isCorrect ? 'bg-emerald-100 text-emerald-700' :
                          isSkipped ? 'bg-gray-100 text-gray-500' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {isCorrect ? <CheckCircle2 className="w-4 h-4" /> :
                           isSkipped ? <SkipForward className="w-4 h-4" /> :
                           <XCircle className="w-4 h-4" />}
                        </span>
                        <p className="text-sm font-medium">{i + 1}. {q.questionText}</p>
                      </div>

                      <div className="ml-8 space-y-1 text-xs">
                        {['A', 'B', 'C', 'D'].map(letter => {
                          const isUserAnswer = userAnswer === letter
                          const isCorrectOption = q.correctAnswer === letter
                          let optionClass = 'text-gray-500'
                          if (isCorrectOption) optionClass = 'text-emerald-600 font-semibold'
                          if (isUserAnswer && !isCorrect) optionClass = 'text-red-600 line-through'
                          if (isUserAnswer && isCorrect) optionClass = 'text-emerald-600 font-semibold'

                          const optionText = letter === 'A' ? q.optionA : letter === 'B' ? q.optionB : letter === 'C' ? q.optionC : q.optionD
                          return (
                            <p key={letter} className={optionClass}>
                              {letter}. {optionText}
                              {isUserAnswer && ` (${_t('results.yourAnswer')})`}
                              {isCorrectOption && ' ✓'}
                            </p>
                          )
                        })}
                      </div>

                      {q.explanation && (
                        <div className="ml-8 mt-2 p-2 bg-blue-50 rounded-lg text-xs text-blue-700">
                          💡 {q.explanation}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )
              })}
            </div>
            )}
          </div>

          <Button
            className="w-full rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white"
            onClick={() => { scrollPositionsRef.current.set(currentPage, window.scrollY); pageHistoryRef.current = []; setCurrentPage('home') }}
          >
            <Home className="w-4 h-4 mr-2" /> {_t('results.backHome')}
          </Button>
        </div>
      </div>
    )
  }

  // ===== RENDER: Leaderboard =====
  function renderLeaderboard() {
    return (
      <div className="pb-20">
        <div className="bg-gradient-to-r from-orange-500 to-red-500 px-4 pt-[calc(env(safe-area-inset-top,0px)+3rem)] pb-6 rounded-b-3xl">
          <div className="flex items-center gap-3">
            <button onClick={goBack} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <Trophy className="w-6 h-6 text-yellow-300" />
            <h1 className="text-white text-xl font-bold">{_t('leaderboard.title')}</h1>
          </div>
        </div>

        <div className="px-4 mt-4">
          {leaderboardData.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-8 text-center">
                <Trophy className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="font-semibold text-gray-400">{_t('leaderboard.noResults')}</p>
                <p className="text-gray-400 text-sm mt-1">{_t('leaderboard.beFirst')}</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {leaderboardData.map((result, index) => {
                const percentage = Math.round((result.score / result.maxScore) * 100)
                const medals = ['🥇', '🥈', '🥉']
                return (
                  <Card key={result.id} className={`border-0 shadow-sm ${index < 3 ? 'bg-gradient-to-r from-yellow-50 to-orange-50' : ''}`}>
                    <CardContent className="p-3 flex items-center gap-3">
                      <span className="w-8 text-center font-bold text-lg">
                        {index < 3 ? medals[index] : `${index + 1}`}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{result.testName}</p>
                        <p className="text-gray-400 text-xs">{formatTime(result.timeTaken)} · {result.createdAt ? new Date(result.createdAt).toLocaleDateString() : ''}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-orange-600">{result.score}/{result.maxScore}</p>
                        <p className="text-gray-400 text-xs">{percentage}%</p>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </div>
      </div>
    )
  }

  // ===== RENDER: Practice Page =====
  function renderPractice() {
    // Gather stats for practice page
    const totalBookmarked = bookmarkedQs.length

    // Calculate weak areas from recent results
    const getWeakAreas = () => {
      try {
        const storedResults = localStorage.getItem('mockmaster_results')
        const allResults: TestResult[] = storedResults ? JSON.parse(storedResults) : []
        if (allResults.length === 0) return []
        // Analyze last 10 results for weak categories
        const recentResults = allResults.slice(-10)
        const categoryScores: Record<string, { correct: number; total: number }> = {}
        recentResults.forEach(r => {
          const catName = r.examName || r.testName || 'Unknown'
          if (!categoryScores[catName]) categoryScores[catName] = { correct: 0, total: 0 }
          categoryScores[catName].correct += r.correctAnswers
          categoryScores[catName].total += r.totalQuestions
        })
        return Object.entries(categoryScores)
          .map(([name, { correct, total }]) => ({ name, accuracy: total > 0 ? Math.round((correct / total) * 100) : 0, total }))
          .filter(a => a.total >= 3 && a.accuracy < 60)
          .sort((a, b) => a.accuracy - b.accuracy)
          .slice(0, 5)
      } catch {
        return []
      }
    }
    const weakAreas = getWeakAreas()

    return (
      <div className="pb-20 secure-content" style={{ userSelect: 'none', WebkitUserSelect: 'none' }} onContextMenu={e => e.preventDefault()}>
        <div className="bg-gradient-to-r from-orange-500 to-red-500 px-4 pt-[calc(env(safe-area-inset-top,0px)+3rem)] pb-6 rounded-b-3xl">
          <div className="flex items-center gap-3 mb-2">
            <button onClick={goBack} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <div>
              <h1 className="text-white text-xl font-bold">{_t('practice.title')}</h1>
              <p className="text-orange-100 text-xs">{_t('practice.subtitle')}</p>
            </div>
          </div>
        </div>

        <div className="px-4 mt-4 space-y-4">
          {/* Practice Mode Selection */}
          <div>
            <h2 className="font-bold text-lg mb-3">{_t('practice.chooseMode')}</h2>
            <div className="grid grid-cols-2 gap-3">
              {/* Quick Practice - Pick a random test and start */}
              <Card className={`border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow active:scale-[0.97] ${auth.needsRealAccount && !auth.canGuestUseQuickPractice ? 'opacity-60' : ''}`} onClick={handleQuickPractice}>
                <CardContent className="p-4 text-center">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-2 ${auth.needsRealAccount && !auth.canGuestUseQuickPractice ? 'bg-gray-100' : 'bg-orange-50'}`}>
                    {auth.needsRealAccount && !auth.canGuestUseQuickPractice ? (
                      <Lock className="w-6 h-6 text-gray-400" />
                    ) : (
                      <Zap className="w-6 h-6 text-orange-500" />
                    )}
                  </div>
                  <p className="font-semibold text-sm">{_t('practice.quick')}</p>
                  <p className="text-gray-400 text-[11px] mt-1">
                    {auth.needsRealAccount && !auth.canGuestUseQuickPractice
                      ? _t('guest.alreadyUsed')
                      : _t('practice.quickSub')}
                  </p>
                </CardContent>
              </Card>
              {/* Topic Wise - Navigate to exams with practice mode */}
              <Card className={`border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow active:scale-[0.97] ${auth.needsRealAccount ? 'opacity-80' : ''}`} onClick={() => {
                if (!requireAuth()) return
                setCurrentTestMode('practice')
                navigateTo('exams')
              }}>
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center mx-auto mb-2">
                    <Target className="w-6 h-6 text-blue-500" />
                  </div>
                  <p className="font-semibold text-sm">{_t('practice.topicWise')}</p>
                  <p className="text-gray-400 text-[11px] mt-1">{_t('practice.topicWiseSub')}</p>
                </CardContent>
              </Card>
              {/* Bookmarked Questions - Practice bookmarked questions */}
              <Card className={`border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow active:scale-[0.97] ${totalBookmarked === 0 ? 'opacity-70' : ''} ${auth.needsRealAccount ? 'opacity-80' : ''}`} onClick={() => {
                if (!requireAuth()) return
                if (totalBookmarked === 0) {
                  navigateTo('bookmarks')
                  return
                }
                navigateTo('bookmarks')
              }}>
                {totalBookmarked === 0 && <Badge variant="secondary" className="absolute top-2 right-2 text-[9px]">{_t('menu.soon')}</Badge>}
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-green-50 flex items-center justify-center mx-auto mb-2">
                    <BookMarked className="w-6 h-6 text-green-500" />
                  </div>
                  <p className="font-semibold text-sm">{_t('practice.bookmarked')}</p>
                  <p className="text-gray-400 text-[11px] mt-1">{totalBookmarked > 0 ? `${totalBookmarked} questions` : _t('practice.bookmarkedSub')}</p>
                </CardContent>
              </Card>
              {/* Weak Areas - Practice questions from weak categories */}
              <Card className={`border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow active:scale-[0.97] ${weakAreas.length === 0 ? 'opacity-70' : ''} ${auth.needsRealAccount ? 'opacity-80' : ''}`} onClick={() => {
                if (!requireAuth()) return
                if (weakAreas.length === 0) {
                  navigateTo('perf-report')
                  return
                }
                // Navigate to exams page with practice mode to practice weak areas
                setCurrentTestMode('practice')
                navigateTo('exams')
              }}>
                {weakAreas.length === 0 && <Badge variant="secondary" className="absolute top-2 right-2 text-[9px]">{_t('menu.soon')}</Badge>}
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center mx-auto mb-2">
                    <PenTool className="w-6 h-6 text-purple-500" />
                  </div>
                  <p className="font-semibold text-sm">{_t('practice.weakAreas')}</p>
                  <p className="text-gray-400 text-[11px] mt-1">{weakAreas.length > 0 ? `${weakAreas.length} weak areas` : _t('practice.weakAreasSub')}</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Weak Areas Highlight (if any) */}
          {weakAreas.length > 0 && (
            <div>
              <h2 className="font-bold text-lg mb-3 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" /> Weak Areas
              </h2>
              <div className="space-y-2">
                {weakAreas.map(area => (
                  <Card key={area.name} className="border-0 shadow-sm">
                    <CardContent className="p-3 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                        <span className="font-bold text-sm text-red-600">{area.accuracy}%</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{area.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Progress value={area.accuracy} className="h-1.5 flex-1" />
                          <span className="text-gray-400 text-[10px]">{area.total} Qs</span>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="rounded-xl text-orange-600 border-orange-200 text-xs"
                        onClick={() => {
                          setCurrentTestMode('practice')
                          navigateTo('exams')
                        }}>
                        Practice
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Practice by Category */}
          <div>
            <h2 className="font-bold text-lg mb-3">{_t('practice.byCategory')}</h2>
            <div className="space-y-2">
              {categories.map(cat => {
                const color = getCatColor(cat.slug)
                const totalQs = cat.exams.reduce((sum, e) => sum + e.totalQuestions, 0)
                return (
                  <Card
                    key={cat.id}
                    className={`border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow active:scale-[0.98] ${auth.needsRealAccount ? 'opacity-80' : ''}`}
                    onClick={() => {
                      if (!requireAuth()) return
                      setSelectedCategory(cat)
                      setCurrentTestMode('practice')
                      openExam(cat.exams[0], cat, 'practice')
                    }}
                  >
                    <CardContent className="p-3 flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl ${color.light} flex items-center justify-center ${color.text}`}>
                        {getCatIcon(cat.slug)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm">{cat.name}</p>
                        <p className="text-gray-400 text-xs">{cat.exams.length} {_t('home.exams')} · {totalQs} {_t('about.questions')}</p>
                      </div>
                      <Button size="sm" variant="outline" className="rounded-xl text-orange-600 border-orange-200 text-xs">
                        {_t('home.start')}
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>

          {/* Previous Practice Sessions */}
          <div>
            <h2 className="font-bold text-lg mb-3">{_t('practice.recent')}</h2>
            {auth.isLoggedIn ? (
              (() => {
                try {
                  const storedResults = localStorage.getItem('mockmaster_results')
                  const allResults: TestResult[] = storedResults ? JSON.parse(storedResults) : []
                  const userId = auth.getUserId()
                  const userResults = userId ? allResults.filter((r: TestResult) => r.userId === userId).slice(-5).reverse() : []
                  if (userResults.length === 0) {
                    return (
                      <Card className="border-0 shadow-sm">
                        <CardContent className="p-4 text-center">
                          <Clock className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                          <p className="text-gray-400 text-sm">{_t('practice.historyEmpty')}</p>
                        </CardContent>
                      </Card>
                    )
                  }
                  return (
                    <div className="space-y-2">
                      {userResults.map((r: TestResult) => {
                        const pct = Math.round((r.score / r.totalQuestions) * 100)
                        return (
                          <Card key={r.id} className="border-0 shadow-sm">
                            <CardContent className="p-3 flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${pct >= 60 ? 'bg-emerald-50' : pct >= 40 ? 'bg-yellow-50' : 'bg-red-50'}`}>
                                <span className={`font-bold text-sm ${pct >= 60 ? 'text-emerald-600' : pct >= 40 ? 'text-yellow-600' : 'text-red-600'}`}>{pct}%</span>
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="font-semibold text-sm truncate">{r.testName || r.testId.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</p>
                                <p className="text-gray-400 text-xs">{r.correctAnswers}/{r.totalQuestions} · {Math.round(r.timeTaken / 60)}m</p>
                              </div>
                              <Badge variant="outline" className="text-[10px]">{r.correctAnswers} ✓</Badge>
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  )
                } catch {
                  return (
                    <Card className="border-0 shadow-sm">
                      <CardContent className="p-4 text-center">
                        <Clock className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                        <p className="text-gray-400 text-sm">{_t('practice.historyEmpty')}</p>
                      </CardContent>
                    </Card>
                  )
                }
              })()
            ) : (
              <Card className="border-0 shadow-sm bg-gradient-to-r from-orange-50 to-red-50">
                <CardContent className="p-4 text-center">
                  <PenTool className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                  <p className="font-semibold text-sm text-gray-700">{_t('practice.loginSave')}</p>
                  <Button size="sm" className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl mt-2" onClick={() => setShowLoginModal(true)}>
                    {_t('home.loginNow')}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    )
  }

  // ===== RENDER: Bookmarked Questions =====
  function renderBookmarks() {
    // Collect all bookmarked questions from all tests
    const allBookmarkedQuestions: { question: LocalQuestion; testTitle: string; examName: string }[] = []
    categories.forEach(cat => {
      cat.exams.forEach(exam => {
        // We need to get tests for each exam - use local data
        const tests = getLocalTestsByExam(exam.id)
        tests.forEach(test => {
          test.questions.forEach(q => {
            if (bookmarkedQs.includes(q.id)) {
              allBookmarkedQuestions.push({ question: q, testTitle: test.title, examName: exam.name })
            }
          })
        })
      })
    })

    return (
      <div className="min-h-screen bg-gray-50 secure-content" style={{ userSelect: 'none', WebkitUserSelect: 'none' }} onContextMenu={e => e.preventDefault()}>
        {/* Header */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 pt-[calc(env(safe-area-inset-top,0px)+1rem)] pb-5">
          <div className="flex items-center gap-3 mb-3">
            <button onClick={goBack} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center" style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-lg font-bold">{_t('bookmarks.title')}</h1>
            <Badge variant="secondary" className="ml-auto">{allBookmarkedQuestions.length}</Badge>
          </div>
          <p className="text-white/50 text-xs">{_t('bookmarks.subtitle')}</p>
        </div>

        <div className="px-4 mt-4 space-y-3 pb-24">
          {allBookmarkedQuestions.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-8 text-center">
                <BookMarked className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="font-semibold text-gray-600">{_t('bookmarks.empty')}</p>
                <p className="text-gray-400 text-xs mt-1">{_t('bookmarks.emptySub')}</p>
                <Button size="sm" className="mt-4 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl" onClick={() => handleBottomNav('practice')}>
                  {_t('nav.practice')}
                </Button>
              </CardContent>
            </Card>
          ) : (
            allBookmarkedQuestions.map((item, i) => (
              <Card key={item.question.id} className="border-0 shadow-sm relative overflow-hidden secure-content" onContextMenu={e => e.preventDefault()}>
                {/* Watermark for copy protection */}
                <div className="watermark-overlay" />
                <CardContent className="p-4 relative z-10">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center shrink-0">
                      <span className="text-orange-600 font-bold text-sm">{i + 1}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 leading-relaxed">{item.question.questionText}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {['A', 'B', 'C', 'D'].map(letter => {
                          const optionText = letter === 'A' ? item.question.optionA : letter === 'B' ? item.question.optionB : letter === 'C' ? item.question.optionC : item.question.optionD
                          const isCorrect = item.question.correctAnswer === letter
                          return (
                            <span key={letter} className={`text-[11px] px-2 py-0.5 rounded-full ${isCorrect ? 'bg-emerald-50 text-emerald-700 font-semibold' : 'bg-gray-100 text-gray-600'}`}>
                              {letter}. {optionText}
                            </span>
                          )
                        })}
                      </div>
                      {item.question.explanation && (
                        <p className="text-[11px] text-blue-600 mt-2 bg-blue-50 rounded-lg p-2">{item.question.explanation}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline" className="text-[9px]">{item.testTitle}</Badge>
                        <Badge variant="outline" className="text-[9px]">{item.examName}</Badge>
                      </div>
                    </div>
                    <button onClick={() => toggleBookmark(item.question.id)} className="shrink-0 w-8 h-8 rounded-full bg-red-50 flex items-center justify-center" style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>
                      <X className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    )
  }

  // ===== RENDER: Performance Report =====
  function renderPerfReport() {
    const stats = userStats
    let results: TestResult[] = []
    try {
      const stored = localStorage.getItem('examprep_results')
      if (stored) results = JSON.parse(stored)
      const userId = auth.getUserId()
      if (userId) results = results.filter((r: TestResult) => r.userId === userId)
    } catch {}

    // Calculate analytics
    const totalTests = results.length
    const avgScore = stats.avgScore
    const avgTime = totalTests > 0 ? Math.round(results.reduce((s, r) => s + r.timeTaken, 0) / totalTests / 60) : 0
    const avgAccuracy = totalTests > 0 ? Math.round(results.reduce((s, r) => s + ((r.correctCount || (r as any).correctAnswers || 0) / ((r.totalQuestions || (r as any).totalQuestions) || 1)) * 100, 0) / totalTests) : 0
    const last5 = results.slice(-5).reverse()
    const scoreTrend = last5.map(r => Math.round((r.score / (r.totalQuestions || (r as any).totalQuestions || 1)) * 100))

    // Subject-wise performance
    const examPerformance: Record<string, { count: number; avgPct: number }> = {}
    results.forEach(r => {
      const key = r.testId.split('-').slice(0, 3).join('-')
      if (!examPerformance[key]) examPerformance[key] = { count: 0, avgPct: 0 }
      examPerformance[key].count++
      examPerformance[key].avgPct += (r.correctAnswers / r.totalQuestions) * 100
    })
    Object.keys(examPerformance).forEach(k => {
      examPerformance[k].avgPct = Math.round(examPerformance[k].avgPct / examPerformance[k].count)
    })

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 pt-[calc(env(safe-area-inset-top,0px)+1rem)] pb-5">
          <div className="flex items-center gap-3 mb-3">
            <button onClick={goBack} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center" style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-lg font-bold">{_t('perf.title')}</h1>
          </div>
        </div>

        <div className="px-4 mt-4 space-y-4 pb-24">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <FileText className="w-5 h-5 text-orange-500 mx-auto mb-1" />
                <p className="font-bold text-xl">{totalTests}</p>
                <p className="text-gray-400 text-[10px]">{_t('perf.testsTaken')}</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <Target className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
                <p className="font-bold text-xl">{avgAccuracy}%</p>
                <p className="text-gray-400 text-[10px]">{_t('perf.accuracy')}</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <Award className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                <p className="font-bold text-xl">#{stats.bestRank || '-'}</p>
                <p className="text-gray-400 text-[10px]">{_t('home.bestRank')}</p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3 text-center">
                <Clock className="w-5 h-5 text-purple-500 mx-auto mb-1" />
                <p className="font-bold text-xl">{avgTime}m</p>
                <p className="text-gray-400 text-[10px]">{_t('perf.avgTime')}</p>
              </CardContent>
            </Card>
          </div>

          {/* Score Trend */}
          {scoreTrend.length > 1 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h3 className="font-semibold text-sm mb-3">{_t('perf.scoreTrend')}</h3>
                <div className="flex items-end gap-2 h-24">
                  {scoreTrend.map((score, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <span className="text-[9px] font-bold" style={{ color: score >= 60 ? '#10b981' : score >= 40 ? '#f59e0b' : '#ef4444' }}>{score}%</span>
                      <div className="w-full rounded-t-md" style={{ height: `${Math.max(score, 5)}%`, background: score >= 60 ? '#10b981' : score >= 40 ? '#f59e0b' : '#ef4444' }} />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Results */}
          {last5.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h3 className="font-semibold text-sm mb-3">{_t('perf.recentTests')}</h3>
                <div className="space-y-2">
                  {last5.map(r => {
                    const pct = Math.round((r.score / r.totalQuestions) * 100)
                    return (
                      <div key={r.id} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${pct >= 60 ? 'bg-emerald-50' : pct >= 40 ? 'bg-yellow-50' : 'bg-red-50'}`}>
                          <span className={`font-bold text-xs ${pct >= 60 ? 'text-emerald-600' : pct >= 40 ? 'text-yellow-600' : 'text-red-600'}`}>{pct}%</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium truncate">{r.correctAnswers}/{r.totalQuestions} {_t('perf.correct')}</p>
                          <p className="text-[10px] text-gray-400">{Math.round(r.timeTaken / 60)}m · {r.wrongAnswers} ✗ · {r.skipped} −</p>
                        </div>
                        <div className="w-16">
                          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct >= 60 ? '#10b981' : pct >= 40 ? '#f59e0b' : '#ef4444' }} />
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {totalTests === 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="font-semibold text-gray-600">{_t('perf.noData')}</p>
                <p className="text-gray-400 text-xs mt-1">{_t('perf.noDataSub')}</p>
                <Button size="sm" className="mt-4 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl" onClick={() => handleBottomNav('practice')}>
                  {_t('nav.practice')}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // ===== RENDER: Daily Practice Routine =====
  function renderDailyRoutine() {
    const userExam = categories.flatMap(c => c.exams).find(e => e.id === userExamId)
    const timeSlots = [
      { id: 'morning', icon: '🌅', label: _t('routine.morning'), time: '6-9 AM' },
      { id: 'afternoon', icon: '☀️', label: _t('routine.afternoon'), time: '12-3 PM' },
      { id: 'evening', icon: '🌇', label: _t('routine.evening'), time: '5-8 PM' },
      { id: 'night', icon: '🌙', label: _t('routine.night'), time: '9-11 PM' },
    ]
    const questionCounts = [5, 10, 15, 20, 25, 30]

    // Check today's practice
    const today = new Date().toDateString()
    let todayResults: TestResult[] = []
    try {
      const stored = localStorage.getItem('mockmaster_results')
      if (stored) {
        const all: TestResult[] = JSON.parse(stored)
        const userId = auth.getUserId()
        todayResults = all.filter((r: TestResult) => {
          const rDate = new Date(r.createdAt).toDateString()
          return rDate === today && (!userId || r.userId === userId)
        })
      }
    } catch {}
    const todayQuestions = todayResults.reduce((s, r) => s + r.totalQuestions, 0)
    const dailyGoal = dailyRoutine.questionCount
    const goalMet = todayQuestions >= dailyGoal

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 pt-[calc(env(safe-area-inset-top,0px)+1rem)] pb-5">
          <div className="flex items-center gap-3 mb-3">
            <button onClick={goBack} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center" style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-lg font-bold">{_t('routine.title')}</h1>
          </div>
        </div>

        <div className="px-4 mt-4 space-y-4 pb-24">
          {/* Today's Progress */}
          <Card className={`border-0 shadow-sm ${goalMet ? 'bg-gradient-to-r from-emerald-50 to-green-50' : 'bg-gradient-to-r from-orange-50 to-red-50'}`}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-2">
                {goalMet ? <CheckCircle2 className="w-6 h-6 text-emerald-500" /> : <Zap className="w-6 h-6 text-orange-500" />}
                <div>
                  <p className="font-bold text-sm">{goalMet ? _t('routine.goalMet') : _t('routine.todayProgress')}</p>
                  <p className="text-gray-500 text-xs">{todayQuestions} / {dailyGoal} {_t('routine.questions')}</p>
                </div>
              </div>
              <div className="h-2 bg-white/60 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all" style={{ width: `${Math.min((todayQuestions / dailyGoal) * 100, 100)}%`, background: goalMet ? '#10b981' : '#f97316' }} />
              </div>
            </CardContent>
          </Card>

          {/* Select Exam */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm mb-3">{_t('routine.selectExam')}</h3>
              <div className="grid grid-cols-2 gap-2">
                {categories.flatMap(c => c.exams).map(exam => (
                  <button key={exam.id} onClick={() => { setUserExamId(exam.id); setDailyRoutine(prev => ({ ...prev, examId: exam.id })) }}
                    className={`p-2.5 rounded-xl text-xs font-medium transition-colors ${userExamId === exam.id ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600 active:bg-gray-200'}`}
                    style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                  >
                    {exam.name}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Daily Goal */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm mb-3">{_t('routine.dailyGoal')}</h3>
              <div className="flex flex-wrap gap-2">
                {questionCounts.map(n => (
                  <button key={n} onClick={() => setDailyRoutine(prev => ({ ...prev, questionCount: n }))}
                    className={`px-4 py-2 rounded-xl text-xs font-medium transition-colors ${dailyRoutine.questionCount === n ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600 active:bg-gray-200'}`}
                    style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                  >
                    {n} Qs
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Preferred Time */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm mb-3">{_t('routine.preferredTime')}</h3>
              <div className="grid grid-cols-2 gap-2">
                {timeSlots.map(slot => (
                  <button key={slot.id} onClick={() => setDailyRoutine(prev => ({ ...prev, preferredTime: slot.id }))}
                    className={`p-3 rounded-xl text-left transition-colors ${dailyRoutine.preferredTime === slot.id ? 'bg-orange-50 border-2 border-orange-300' : 'bg-gray-50 border-2 border-transparent active:bg-gray-100'}`}
                    style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                  >
                    <span className="text-lg">{slot.icon}</span>
                    <p className="font-medium text-xs mt-1">{slot.label}</p>
                    <p className="text-gray-400 text-[10px]">{slot.time}</p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Start Practice */}
          <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl h-12 font-bold" onClick={() => {
            if (!requireAuth()) return
            if (userExamId) {
              const exam = categories.flatMap(c => c.exams).find(e => e.id === userExamId)
              const cat = categories.find(c => c.exams.some(e => e.id === userExamId))
              if (exam && cat) openExam(exam, cat)
            } else {
              handleBottomNav('practice')
            }
          }}>
            {userExam ? `${_t('routine.practiceFor')} ${userExam.name}` : _t('nav.practice')}
          </Button>
        </div>
      </div>
    )
  }

  // ===== RENDER: Previous Year Papers =====
  function renderPrevPapers() {
    // Admin-managed previous year papers, grouped by year
    const years = [...new Set(prevPapers.map(p => p.year))].sort((a, b) => Number(b) - Number(a))
    const currentYear = selectedPaperYear || years[0] || ''
    const filteredPapers = prevPapers.filter(p => p.year === currentYear)

    // Also keep local tests as fallback
    const allTestsByExam: Record<string, { exam: LocalExam; cat: LocalExamCategory; tests: LocalTest[] }> = {}
    categories.forEach(cat => {
      cat.exams.forEach(exam => {
        const tests = getLocalTestsByExam(exam.id)
        if (tests.length > 0) {
          allTestsByExam[exam.id] = { exam, cat, tests }
        }
      })
    })

    // Find matching test for a paper
    const findTestForPaper = (paper: PrevYearPaper) => {
      // Try to find by testId first
      if (paper.testId) {
        for (const cat of categories) {
          for (const exam of cat.exams) {
            const tests = getLocalTestsByExam(exam.id)
            const found = tests.find(t => t.id === paper.testId)
            if (found) return { test: found, exam, cat }
          }
        }
      }
      // Fallback: find by category
      const cat = categories.find(c => c.slug === paper.examCategory)
      if (cat && cat.exams.length > 0) {
        const exam = cat.exams[0]
        const tests = getLocalTestsByExam(exam.id)
        if (tests.length > 0) return { test: tests[0], exam, cat }
      }
      return null
    }

    // Start paper test from its questions
    const startPaperTest = (paper: PrevYearPaper) => {
      const questions = paper.questions || []
      if (questions.length === 0) {
        // No questions, go to practice page
        navigateTo('practice')
        return
      }
      // Convert PaperQuestion[] to LocalQuestion[]
      const localQuestions: LocalQuestion[] = questions.map(q => ({
        id: q.id,
        questionText: q.questionText,
        optionA: q.optionA,
        optionB: q.optionB,
        optionC: q.optionC,
        optionD: q.optionD,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
      }))
      // Create a temporary LocalTest from the paper
      const paperTest: LocalTest = {
        id: `paper-${paper.id}`,
        examId: '',
        title: paper.name,
        description: `Previous Year Paper - ${paper.year}`,
        duration: paper.duration,
        totalMarks: questions.length,
        passingMarks: Math.round(questions.length * 0.4),
        questions: localQuestions,
        createdAt: new Date().toISOString(),
      }
      // Find category for styling
      const cat = categories.find(c => c.slug === paper.examCategory) || categories[0]
      const exam = cat.exams[0] || { id: '', name: paper.name, icon: '📝', slug: paper.examCategory, tests: [] }
      setSelectedTest(paperTest)
      setSelectedCategory(cat)
      setSelectedExam(exam as LocalExam)
      navigateTo('test-info')
    }

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 pt-[calc(env(safe-area-inset-top,0px)+1rem)] pb-5">
          <div className="flex items-center gap-3 mb-3">
            <button onClick={goBack} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center" style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-lg font-bold">{_t('prevPapers.title')}</h1>
          </div>
          <p className="text-white/50 text-xs">{_t('prevPapers.subtitle')}</p>
        </div>

        <div className="px-4 mt-4 space-y-4 pb-24">
          {/* Year Tabs */}
          {years.length > 0 && (
            <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
              {years.map(year => (
                <button
                  key={year}
                  onClick={() => setSelectedPaperYear(year)}
                  className={`flex-shrink-0 px-5 py-2.5 rounded-xl text-sm font-bold transition-all ${
                    currentYear === year
                      ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-md'
                      : 'bg-white text-gray-600 shadow-sm hover:bg-gray-100'
                  }`}
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                >
                  {year}
                </button>
              ))}
            </div>
          )}

          {/* Papers for selected year */}
          {filteredPapers.length > 0 ? filteredPapers.map(paper => {
            const paperQuestions = paper.questions || []
            const hasQuestions = paperQuestions.length > 0
            const match = findTestForPaper(paper)
            const cat = categories.find(c => c.slug === paper.examCategory)
            const canPlay = hasQuestions || match
            return (
              <Card key={paper.id} className="border-0 shadow-sm overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex items-center gap-3 p-3">
                    <div className={`w-11 h-11 rounded-2xl ${cat ? getCatColor(cat.slug).light : 'bg-blue-50'} flex items-center justify-center`}>
                      {cat ? getCatIcon(cat.slug) : <FileText className="w-5 h-5 text-blue-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{paper.name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-gray-400 text-xs">{hasQuestions ? `${paperQuestions.length} Qs` : `${paper.totalQuestions} Qs`} · {paper.duration}m</span>
                        <Badge className={`text-[9px] border-0 ${
                          paper.difficulty === 'Easy' ? 'bg-emerald-100 text-emerald-700' :
                          paper.difficulty === 'Hard' ? 'bg-red-100 text-red-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {paper.difficulty}
                        </Badge>
                        {hasQuestions && (
                          <Badge className="text-[9px] border-0 bg-blue-100 text-blue-700">{paperQuestions.length} questions ready</Badge>
                        )}
                      </div>
                    </div>
                    {canPlay ? (
                      <button
                        onClick={() => {
                          if (hasQuestions) {
                            startPaperTest(paper)
                          } else if (match) {
                            setSelectedTest(match.test); setSelectedCategory(match.cat); setSelectedExam(match.exam); navigateTo('test-info')
                          }
                        }}
                        className="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-400 to-red-400 flex items-center justify-center shadow-sm"
                        style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                      >
                        <Play className="w-4 h-4 text-white" />
                      </button>
                    ) : (
                      <Badge className="text-[9px] border-0 bg-gray-100 text-gray-500">No Questions</Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          }) : (
            // Fallback: show all tests by exam if no admin papers
            Object.values(allTestsByExam).map(({ exam, cat, tests }) => (
              <Card key={exam.id} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-10 h-10 rounded-xl ${getCatColor(cat.slug).light} flex items-center justify-center ${getCatColor(cat.slug).text}`}>
                      {getCatIcon(cat.slug)}
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{exam.name}</p>
                      <p className="text-gray-400 text-xs">{tests.length} {_t('prevPapers.papers')}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {tests.map(test => (
                      <button key={test.id} onClick={() => { setSelectedTest(test); setSelectedCategory(cat); setSelectedExam(exam); navigateTo('test-info') }}
                        className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 active:bg-gray-200 transition-colors"
                        style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                      >
                        <FileText className="w-4 h-4 text-orange-500" />
                        <div className="flex-1 text-left">
                          <p className="font-medium text-xs">{test.title}</p>
                          <p className="text-gray-400 text-[10px]">{test.totalQuestions} Qs · {test.duration}m · {test.difficulty}</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-300" />
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    )
  }

  // ===== RENDER: Your Exam =====
  function renderYourExam() {
    const selectedExamData = userExamId ? categories.flatMap(c => c.exams).find(e => e.id === userExamId) : null
    const selectedCatData = userExamId ? categories.find(c => c.exams.some(e => e.id === userExamId)) : null

    // Get user's results for this exam
    let examResults: TestResult[] = []
    try {
      const stored = localStorage.getItem('mockmaster_results')
      if (stored && userExamId) {
        const all: TestResult[] = JSON.parse(stored)
        const userId = auth.getUserId()
        const tests = getLocalTestsByExam(userExamId)
        const testIds = tests.map(t => t.id)
        examResults = all.filter((r: TestResult) => testIds.includes(r.testId) && (!userId || r.userId === userId))
      }
    } catch {}

    const totalAttempts = examResults.length
    const avgPct = totalAttempts > 0 ? Math.round(examResults.reduce((s, r) => s + (r.correctAnswers / r.totalQuestions) * 100, 0) / totalAttempts) : 0
    const bestPct = totalAttempts > 0 ? Math.round(Math.max(...examResults.map(r => (r.correctAnswers / r.totalQuestions) * 100))) : 0

    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 pt-[calc(env(safe-area-inset-top,0px)+1rem)] pb-5">
          <div className="flex items-center gap-3 mb-3">
            <button onClick={goBack} className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center" style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}>
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
            <h1 className="text-white text-lg font-bold">{_t('yourExam.title')}</h1>
          </div>
        </div>

        <div className="px-4 mt-4 space-y-4 pb-24">
          {/* Select Your Exam */}
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm mb-3">{_t('yourExam.selectExam')}</h3>
              <p className="text-gray-400 text-xs mb-3">{_t('yourExam.selectSub')}</p>
              <div className="space-y-2">
                {categories.map(cat => (
                  <div key={cat.id}>
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">{cat.name}</p>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {cat.exams.map(exam => (
                        <button key={exam.id} onClick={() => setUserExamId(exam.id)}
                          className={`px-3 py-2 rounded-xl text-xs font-medium transition-colors ${userExamId === exam.id ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' : 'bg-gray-100 text-gray-600 active:bg-gray-200'}`}
                          style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                        >
                          {exam.name}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Selected Exam Stats */}
          {selectedExamData && selectedCatData && (
            <>
              <Card className="border-0 shadow-sm bg-gradient-to-r from-orange-50 to-red-50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-12 h-12 rounded-xl ${getCatColor(selectedCatData.slug).light} flex items-center justify-center ${getCatColor(selectedCatData.slug).text}`}>
                      {getCatIcon(selectedCatData.slug)}
                    </div>
                    <div>
                      <p className="font-bold">{selectedExamData.name}</p>
                      <p className="text-gray-500 text-xs">{selectedExamData.description}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center p-2 bg-white/60 rounded-lg">
                      <p className="font-bold text-sm">{totalAttempts}</p>
                      <p className="text-[9px] text-gray-500">{_t('yourExam.attempts')}</p>
                    </div>
                    <div className="text-center p-2 bg-white/60 rounded-lg">
                      <p className="font-bold text-sm">{avgPct}%</p>
                      <p className="text-[9px] text-gray-500">{_t('yourExam.avg')}</p>
                    </div>
                    <div className="text-center p-2 bg-white/60 rounded-lg">
                      <p className="font-bold text-sm">{bestPct}%</p>
                      <p className="text-[9px] text-gray-500">{_t('yourExam.best')}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Available Tests */}
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-sm mb-3">{_t('yourExam.availableTests')}</h3>
                  <div className="space-y-2">
                    {getLocalTestsByExam(userExamId).map(test => (
                      <button key={test.id} onClick={() => { setSelectedTest(test); setSelectedCategory(selectedCatData); setSelectedExam(selectedExamData); navigateTo('test-info') }}
                        className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 active:bg-gray-200 transition-colors"
                        style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                      >
                        <ClipboardList className="w-4 h-4 text-orange-500" />
                        <div className="flex-1 text-left">
                          <p className="font-medium text-xs">{test.title}</p>
                          <p className="text-gray-400 text-[10px]">{test.totalQuestions} Qs · {test.duration}m</p>
                        </div>
                        <Button size="sm" variant="outline" className="rounded-xl text-orange-600 border-orange-200 text-[10px] h-7">
                          {_t('home.start')}
                        </Button>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {!userExamId && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-8 text-center">
                <Target className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="font-semibold text-gray-600">{_t('yourExam.noExam')}</p>
                <p className="text-gray-400 text-xs mt-1">{_t('yourExam.noExamSub')}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }
  function renderProfile() {
    const stats = userStats
    const userDisplay = auth.getUserDisplay()
    const userEmail = auth.getUserEmail()
    const isEmailUser = !auth.isGuest && auth.isLoggedIn
    const hasProfileData = profileData.fullName || profileData.dateOfBirth || profileData.category || profileData.education || profileData.address || profileData.phone || profileData.state || profileData.gender || profileData.targetExam

    const indianStates = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Delhi','Jammu & Kashmir','Ladakh']

    return (
      <div className="pb-20">
        {/* Header with gradient */}
        <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 px-5 pt-[calc(env(safe-area-inset-top,0px)+3rem)] pb-14 rounded-b-[32px] relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-44 h-44 bg-purple-500/10 rounded-full -translate-y-1/2 translate-x-1/4 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-36 h-36 bg-orange-500/10 rounded-full translate-y-1/2 -translate-x-1/4 blur-2xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl" />

          {/* Top bar */}
          <div className="flex items-center justify-between mb-6 relative z-10">
            <h1 className="text-white text-xl font-extrabold tracking-tight">{_t('profile.title')}</h1>
            <button
              onClick={() => setShowLanguageSheet(true)}
              className="w-9 h-9 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <BookOpen className="w-4 h-4 text-white/70" />
            </button>
          </div>

          {/* Profile Card */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/10 relative z-10">
            <div className="flex items-center gap-4">
              {/* Avatar with camera overlay */}
              <div className="relative">
                <div className="w-[72px] h-[72px] rounded-full bg-gradient-to-br from-orange-400 via-rose-500 to-pink-500 flex items-center justify-center shadow-xl shadow-orange-500/25 ring-2 ring-white/20">
                  <span className="text-white font-bold text-2xl">{getAvatarDisplay()}</span>
                </div>
                {isEmailUser && (
                  <div className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center border-2 border-slate-900 shadow-sm">
                    <CheckCircle2 className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-lg truncate">
                  {profileData.fullName || (isEmailUser ? (userDisplay || userEmail) : _t('profile.guestUser'))}
                </p>
                {profileData.targetExam && (
                  <p className="text-orange-300 text-xs font-medium mt-0.5 flex items-center gap-1">
                    <Target className="w-3 h-3" /> {profileData.targetExam}
                  </p>
                )}
                <div className="flex items-center gap-2 mt-1.5">
                  {isEmailUser ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[11px] font-semibold">
                      <Shield className="w-3 h-3" /> {_t('profile.verified')}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[11px] font-semibold">
                      <AlertTriangle className="w-3 h-3" /> {_t('profile.guestMode')}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Stats Row */}
            <div className="mt-5 pt-4 border-t border-white/10 grid grid-cols-3 gap-2">
              <div className="text-center">
                <p className="text-white font-extrabold text-xl">{stats.testsTaken || '-'}</p>
                <p className="text-white/40 text-[9px] font-semibold uppercase tracking-widest">{_t('profile.tests')}</p>
              </div>
              <div className="text-center border-x border-white/10">
                <p className="text-white font-extrabold text-xl">{stats.avgScore ? `${stats.avgScore}%` : '-'}</p>
                <p className="text-white/40 text-[9px] font-semibold uppercase tracking-widest">{_t('profile.avgScore')}</p>
              </div>
              <div className="text-center">
                <p className="text-white font-extrabold text-xl">{stats.bestRank ? `#${stats.bestRank}` : '-'}</p>
                <p className="text-white/40 text-[9px] font-semibold uppercase tracking-widest">{_t('profile.bestRank')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 -mt-6 space-y-4 relative z-20">
          {/* Guest Upgrade Banner */}
          {auth.isGuest && (
            <Card className="border-0 shadow-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
                    <Crown className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-bold text-sm">{_t('profile.upgradeTitle')}</p>
                    <p className="text-white/80 text-[11px] mt-0.5">{_t('profile.upgradeSub')}</p>
                  </div>
                  <Button
                    size="sm"
                    className="bg-white text-orange-600 hover:bg-white/90 rounded-xl font-bold px-3 shadow-lg"
                    onClick={() => setShowLoginModal(true)}
                  >
                    <Mail className="w-3 h-3 mr-1" /> {_t('profile.login')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Not logged in - Login Card */}
          {!auth.isLoggedIn && (
            <Card className="border-0 shadow-xl overflow-hidden">
              <CardContent className="p-5">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-100 to-rose-100 flex items-center justify-center mx-auto mb-3">
                    <User className="w-8 h-8 text-orange-500" />
                  </div>
                  <p className="font-bold text-base">{_t('profile.loginUnlock')}</p>
                  <p className="text-gray-400 text-xs mt-1">{_t('profile.loginUnlockSub')}</p>
                </div>
                <Button
                  className="w-full h-12 bg-gradient-to-r from-orange-500 via-rose-500 to-pink-500 text-white rounded-2xl font-bold text-sm shadow-lg shadow-orange-500/25"
                  onClick={() => setShowLoginModal(true)}
                >
                  <Mail className="w-4 h-4 mr-2" /> {_t('profile.loginEmail')}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Personal Information Section */}
          <div>
            <div className="flex items-center justify-between px-1 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-sm">
                  <User className="w-3.5 h-3.5 text-white" />
                </div>
                <h2 className="font-bold text-[15px] text-gray-800">{_t('profile.personalInfo')}</h2>
              </div>
              <button
                onClick={() => {
                  if (isEditingProfile) {
                    setProfileSaved(true)
                    setTimeout(() => setProfileSaved(false), 2000)
                  }
                  setIsEditingProfile(!isEditingProfile)
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  isEditingProfile
                    ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/25'
                    : 'bg-gradient-to-r from-orange-50 to-rose-50 text-orange-600 border border-orange-200'
                }`}
              >
                {isEditingProfile ? <><Save className="w-3 h-3" /> {_t('profile.saveProfile')}</> : <><Edit3 className="w-3 h-3" /> {_t('profile.editProfile')}</>}
              </button>
            </div>

            {/* Profile Saved Toast */}
            {profileSaved && (
              <div className="mb-3 flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span className="text-emerald-700 text-xs font-bold">{_t('profile.profileSaved')}</span>
              </div>
            )}

            <Card className="border-0 shadow-lg overflow-hidden">
              <CardContent className="p-4 space-y-4">
                {/* Full Name */}
                <div>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <User className="w-3 h-3 text-violet-500" /> {_t('profile.fullName')}
                  </label>
                  {isEditingProfile ? (
                    <input
                      type="text"
                      value={profileData.fullName}
                      onChange={e => setProfileData(prev => ({ ...prev, fullName: e.target.value }))}
                      placeholder={_t('profile.namePlaceholder')}
                      className="w-full h-11 px-4 rounded-xl border-2 border-violet-200 bg-violet-50/50 text-sm font-medium text-gray-800 placeholder:text-gray-300 focus:outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 transition-all"
                    />
                  ) : (
                    <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.fullName ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                      <span className={`text-sm font-medium ${profileData.fullName ? 'text-gray-800' : 'text-gray-300'}`}>{profileData.fullName || _t('profile.namePlaceholder')}</span>
                    </div>
                  )}
                </div>

                {/* Date of Birth & Gender - 2 columns */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-3 h-3 text-blue-500" /> {_t('profile.dateOfBirth')}
                    </label>
                    {isEditingProfile ? (
                      <input
                        type="date"
                        value={profileData.dateOfBirth}
                        onChange={e => setProfileData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                        className="w-full h-11 px-3 rounded-xl border-2 border-blue-200 bg-blue-50/50 text-sm font-medium text-gray-800 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all"
                      />
                    ) : (
                      <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.dateOfBirth ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                        <span className={`text-sm font-medium ${profileData.dateOfBirth ? 'text-gray-800' : 'text-gray-300'}`}>{profileData.dateOfBirth ? new Date(profileData.dateOfBirth).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' }) : _t('profile.dobPlaceholder')}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <User className="w-3 h-3 text-pink-500" /> {_t('profile.gender')}
                    </label>
                    {isEditingProfile ? (
                      <select
                        value={profileData.gender}
                        onChange={e => setProfileData(prev => ({ ...prev, gender: e.target.value }))}
                        className="w-full h-11 px-3 rounded-xl border-2 border-pink-200 bg-pink-50/50 text-sm font-medium text-gray-800 focus:outline-none focus:border-pink-400 focus:ring-2 focus:ring-pink-100 transition-all appearance-none"
                      >
                        <option value="">{_t('profile.gender')}</option>
                        <option value="male">{_t('profile.genderMale')}</option>
                        <option value="female">{_t('profile.genderFemale')}</option>
                        <option value="other">{_t('profile.genderOther')}</option>
                      </select>
                    ) : (
                      <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.gender ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                        <span className={`text-sm font-medium ${profileData.gender ? 'text-gray-800' : 'text-gray-300'}`}>
                          {profileData.gender === 'male' ? _t('profile.genderMale') : profileData.gender === 'female' ? _t('profile.genderFemale') : profileData.gender === 'other' ? _t('profile.genderOther') : _t('profile.gender')}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Category & Education - 2 columns */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <Shield className="w-3 h-3 text-amber-500" /> {_t('profile.category')}
                    </label>
                    {isEditingProfile ? (
                      <select
                        value={profileData.category}
                        onChange={e => setProfileData(prev => ({ ...prev, category: e.target.value }))}
                        className="w-full h-11 px-3 rounded-xl border-2 border-amber-200 bg-amber-50/50 text-sm font-medium text-gray-800 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100 transition-all appearance-none"
                      >
                        <option value="">{_t('profile.category')}</option>
                        <option value="general">{_t('profile.categoryGeneral')}</option>
                        <option value="obc">{_t('profile.categoryOBC')}</option>
                        <option value="sc">{_t('profile.categorySC')}</option>
                        <option value="st">{_t('profile.categoryST')}</option>
                        <option value="ews">{_t('profile.categoryEWS')}</option>
                      </select>
                    ) : (
                      <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.category ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                        <span className={`text-sm font-medium capitalize ${profileData.category ? 'text-gray-800' : 'text-gray-300'}`}>
                          {profileData.category === 'general' ? _t('profile.categoryGeneral') : profileData.category === 'obc' ? _t('profile.categoryOBC') : profileData.category === 'sc' ? _t('profile.categorySC') : profileData.category === 'st' ? _t('profile.categoryST') : profileData.category === 'ews' ? _t('profile.categoryEWS') : _t('profile.category')}
                        </span>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <GraduationCap className="w-3 h-3 text-emerald-500" /> {_t('profile.education')}
                    </label>
                    {isEditingProfile ? (
                      <select
                        value={profileData.education}
                        onChange={e => setProfileData(prev => ({ ...prev, education: e.target.value }))}
                        className="w-full h-11 px-3 rounded-xl border-2 border-emerald-200 bg-emerald-50/50 text-sm font-medium text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100 transition-all appearance-none"
                      >
                        <option value="">{_t('profile.educationPlaceholder')}</option>
                        <option value="10th">{_t('profile.education10th')}</option>
                        <option value="12th">{_t('profile.education12th')}</option>
                        <option value="graduate">{_t('profile.educationGraduate')}</option>
                        <option value="post-graduate">{_t('profile.educationPostGrad')}</option>
                        <option value="other">{_t('profile.educationOther')}</option>
                      </select>
                    ) : (
                      <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.education ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                        <span className={`text-sm font-medium ${profileData.education ? 'text-gray-800' : 'text-gray-300'}`}>
                          {profileData.education === '10th' ? _t('profile.education10th') : profileData.education === '12th' ? _t('profile.education12th') : profileData.education === 'graduate' ? _t('profile.educationGraduate') : profileData.education === 'post-graduate' ? _t('profile.educationPostGrad') : profileData.education === 'other' ? _t('profile.educationOther') : _t('profile.educationPlaceholder')}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Phone & State - 2 columns */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <Phone className="w-3 h-3 text-sky-500" /> {_t('profile.phone')}
                    </label>
                    {isEditingProfile ? (
                      <input
                        type="tel"
                        value={profileData.phone}
                        onChange={e => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                        placeholder={_t('profile.phonePlaceholder')}
                        className="w-full h-11 px-4 rounded-xl border-2 border-sky-200 bg-sky-50/50 text-sm font-medium text-gray-800 placeholder:text-gray-300 focus:outline-none focus:border-sky-400 focus:ring-2 focus:ring-sky-100 transition-all"
                      />
                    ) : (
                      <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.phone ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                        <span className={`text-sm font-medium ${profileData.phone ? 'text-gray-800' : 'text-gray-300'}`}>{profileData.phone || _t('profile.phonePlaceholder')}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <MapPin className="w-3 h-3 text-rose-500" /> {_t('profile.state')}
                    </label>
                    {isEditingProfile ? (
                      <select
                        value={profileData.state}
                        onChange={e => setProfileData(prev => ({ ...prev, state: e.target.value }))}
                        className="w-full h-11 px-3 rounded-xl border-2 border-rose-200 bg-rose-50/50 text-sm font-medium text-gray-800 focus:outline-none focus:border-rose-400 focus:ring-2 focus:ring-rose-100 transition-all appearance-none"
                      >
                        <option value="">{_t('profile.statePlaceholder')}</option>
                        {indianStates.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    ) : (
                      <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.state ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                        <span className={`text-sm font-medium truncate ${profileData.state ? 'text-gray-800' : 'text-gray-300'}`}>{profileData.state || _t('profile.statePlaceholder')}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Target Exam */}
                <div>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <Target className="w-3 h-3 text-orange-500" /> {_t('profile.targetExam')}
                  </label>
                  {isEditingProfile ? (
                    <select
                      value={profileData.targetExam}
                      onChange={e => setProfileData(prev => ({ ...prev, targetExam: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border-2 border-orange-200 bg-orange-50/50 text-sm font-medium text-gray-800 focus:outline-none focus:border-orange-400 focus:ring-2 focus:ring-orange-100 transition-all appearance-none"
                    >
                      <option value="">{_t('profile.targetExamPlaceholder')}</option>
                      {categories.flatMap(cat => cat.exams.map(exam => <option key={exam.id} value={exam.name}>{exam.name}</option>))}
                    </select>
                  ) : (
                    <div className={`h-11 px-4 rounded-xl flex items-center ${profileData.targetExam ? 'bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                      <span className={`text-sm font-medium ${profileData.targetExam ? 'text-orange-700' : 'text-gray-300'}`}>{profileData.targetExam || _t('profile.targetExamPlaceholder')}</span>
                    </div>
                  )}
                </div>

                {/* Address */}
                <div>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                    <MapPin className="w-3 h-3 text-teal-500" /> {_t('profile.address')}
                  </label>
                  {isEditingProfile ? (
                    <textarea
                      value={profileData.address}
                      onChange={e => setProfileData(prev => ({ ...prev, address: e.target.value }))}
                      placeholder={_t('profile.addressPlaceholder')}
                      rows={2}
                      className="w-full px-4 py-3 rounded-xl border-2 border-teal-200 bg-teal-50/50 text-sm font-medium text-gray-800 placeholder:text-gray-300 focus:outline-none focus:border-teal-400 focus:ring-2 focus:ring-teal-100 transition-all resize-none"
                    />
                  ) : (
                    <div className={`px-4 py-3 rounded-xl ${profileData.address ? 'bg-gray-50 border border-gray-100' : 'bg-gray-50/50 border border-dashed border-gray-200'}`}>
                      <span className={`text-sm font-medium ${profileData.address ? 'text-gray-800' : 'text-gray-300'}`}>{profileData.address || _t('profile.addressPlaceholder')}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions Grid */}
          <div className="grid grid-cols-2 gap-3">
            <Card
              className="border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all active:scale-[0.97] overflow-hidden"
              onClick={() => { scrollPositionsRef.current.set(currentPage, window.scrollY); pageHistoryRef.current.push(currentPage); setCurrentPage('exams') }}
            >
              <CardContent className="p-4">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center mb-2.5 shadow-sm">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <p className="font-bold text-sm">{_t('profile.myExams')}</p>
                <p className="text-gray-400 text-[10px] mt-0.5 font-medium">{categories.length} {_t('profile.categories')}</p>
              </CardContent>
            </Card>
            <Card
              className="border-0 shadow-lg cursor-pointer hover:shadow-xl transition-all active:scale-[0.97] overflow-hidden"
              onClick={() => { scrollPositionsRef.current.set(currentPage, window.scrollY); pageHistoryRef.current.push(currentPage); setCurrentPage('leaderboard') }}
            >
              <CardContent className="p-4">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center mb-2.5 shadow-sm">
                  <Trophy className="w-5 h-5 text-white" />
                </div>
                <p className="font-bold text-sm">{_t('leaderboard.title')}</p>
                <p className="text-gray-400 text-[10px] mt-0.5 font-medium">{_t('profile.viewRankings')}</p>
              </CardContent>
            </Card>
          </div>

          {/* Logout Button */}
          {auth.isLoggedIn && !auth.isGuest && (
            <button
              onClick={() => auth.logout()}
              className="w-full flex items-center justify-center gap-2 h-12 rounded-2xl border-2 border-red-200 text-red-500 hover:bg-red-50 active:bg-red-100 font-bold text-sm transition-all"
            >
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-red-400 to-rose-500 flex items-center justify-center">
                <LogOut className="w-3.5 h-3.5 text-white" />
              </div>
              {_t('profile.logout')}
            </button>
          )}

          {/* App Version */}
          <p className="text-center text-gray-300 text-[10px] pt-2 pb-4">{_t('app.versionFull')}</p>
        </div>

      </div>
    )
  }

  // ===== RENDER: Upcoming Exam Detail =====
  function renderUpcomingExamDetail() {
    const exam = selectedUpcomingExam
    if (!exam) return null

    const detailItems: { icon: React.ReactNode; label: string; value: string; isLink?: boolean }[] = []
    if (exam.conductingBody) detailItems.push({ icon: <Building2 className="w-4 h-4" />, label: 'Conducting Body', value: exam.conductingBody })
    if (exam.eligibility) detailItems.push({ icon: <GraduationCap className="w-4 h-4" />, label: 'Eligibility', value: exam.eligibility })
    if (exam.examDate) detailItems.push({ icon: <Calendar className="w-4 h-4" />, label: 'Exam Date', value: exam.examDate })
    if (exam.applicationDeadline) detailItems.push({ icon: <Clock className="w-4 h-4" />, label: 'Application Deadline', value: exam.applicationDeadline })
    if (exam.examMode) detailItems.push({ icon: <Monitor className="w-4 h-4" />, label: 'Exam Mode', value: exam.examMode })
    if (exam.totalPosts) detailItems.push({ icon: <Users className="w-4 h-4" />, label: 'Total Posts', value: exam.totalPosts })
    if (exam.salary) detailItems.push({ icon: <IndianRupee className="w-4 h-4" />, label: 'Salary / Pay Scale', value: exam.salary })
    if (exam.examPattern) detailItems.push({ icon: <FileText className="w-4 h-4" />, label: 'Exam Pattern', value: exam.examPattern })
    if (exam.officialWebsite) detailItems.push({ icon: <Globe className="w-4 h-4" />, label: 'Official Website', value: exam.officialWebsite, isLink: true })
    if (exam.applicationLink) detailItems.push({ icon: <ExternalLink className="w-4 h-4" />, label: 'Apply Now', value: exam.applicationLink, isLink: true })

    return (
      <div className="min-h-screen min-h-dvh bg-slate-50">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-blue-600 via-indigo-600 to-blue-700 text-white overflow-hidden">
          {exam.imageUrl && (
            <>
              <img src={exam.imageUrl} alt={exam.name} className="absolute inset-0 w-full h-full object-cover opacity-30" />
              <div className="absolute inset-0 bg-gradient-to-b from-blue-600/80 via-indigo-600/90 to-blue-700/95" />
            </>
          )}
          <div className="relative z-10 px-3 pt-[calc(env(safe-area-inset-top,0px)+0.75rem)] pb-5">
            <div className="flex items-center gap-3 mb-3">
              <button
                onClick={goBack}
                className="w-9 h-9 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors flex-shrink-0"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-white/60 text-[10px] uppercase tracking-wider font-medium">Upcoming Exam</p>
              </div>
              <Badge className={`text-[10px] font-bold border-0 ${
                exam.statusType === 'open' ? 'bg-emerald-400/30 text-emerald-100' :
                exam.statusType === 'admit' ? 'bg-amber-400/30 text-amber-100' :
                exam.statusType === 'closed' ? 'bg-gray-400/30 text-gray-200' :
                'bg-blue-400/30 text-blue-100'
              }`}>
                {exam.status}
              </Badge>
            </div>
            <h1 className="text-xl font-bold leading-tight">{exam.name}</h1>
            {exam.description && (
              <p className="text-white/70 text-sm mt-2 leading-relaxed">{exam.description}</p>
            )}
            <div className="flex items-center gap-2 mt-3">
              <div className="flex items-center gap-1.5 text-white/80 text-xs">
                <Calendar className="w-3.5 h-3.5" />
                <span>{exam.date}</span>
              </div>
              {exam.conductingBody && (
                <>
                  <span className="text-white/40">|</span>
                  <div className="flex items-center gap-1.5 text-white/80 text-xs">
                    <Building2 className="w-3.5 h-3.5" />
                    <span>{exam.conductingBody}</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="px-3 -mt-3 pb-6 space-y-3">
          {/* Important Dates Card */}
          {exam.importantDates && (
            <Card className="border-0 shadow-md overflow-hidden">
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-2.5">
                <h3 className="text-white font-bold text-sm flex items-center gap-2">
                  <Calendar className="w-4 h-4" /> Important Dates
                </h3>
              </div>
              <CardContent className="p-3">
                <div className="space-y-1.5">
                  {exam.importantDates.split('\n').filter(Boolean).map((line, idx) => {
                    const colonIdx = line.indexOf(':')
                    const label = colonIdx > 0 ? line.substring(0, colonIdx + 1) : ''
                    const value = colonIdx > 0 ? line.substring(colonIdx + 1) : line
                    return (
                      <div key={idx} className="flex items-start gap-2 text-sm">
                        <div className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 flex-shrink-0" />
                        {label ? (
                          <p className="text-gray-700">
                            <span className="font-medium text-gray-900">{label}</span>{value}
                          </p>
                        ) : (
                          <p className="text-gray-700">{line}</p>
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Detail Info Cards */}
          {detailItems.length > 0 && (
            <Card className="border-0 shadow-md overflow-hidden">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-500 px-4 py-2.5">
                <h3 className="text-white font-bold text-sm flex items-center gap-2">
                  <FileText className="w-4 h-4" /> Exam Details
                </h3>
              </div>
              <CardContent className="p-0">
                {detailItems.map((item, idx) => (
                  <div key={idx} className={`flex items-start gap-3 px-4 py-3 ${idx < detailItems.length - 1 ? 'border-b border-gray-50' : ''}`}>
                    <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0 text-blue-500">
                      {item.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider font-medium">{item.label}</p>
                      {item.isLink ? (
                        <a
                          href={item.value}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 text-sm font-medium hover:underline break-all"
                          onClick={e => e.stopPropagation()}
                        >
                          {item.label === 'Apply Now' ? 'Click here to apply →' : item.value}
                        </a>
                      ) : (
                        <p className="text-gray-800 text-sm font-medium">{item.value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Quick Action Buttons */}
          <div className="flex gap-2">
            {exam.applicationLink && (
              <a
                href={exam.applicationLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1"
              >
                <Button className="w-full h-12 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl text-sm font-bold shadow-lg shadow-emerald-200 hover:shadow-xl transition-all">
                  <ExternalLink className="w-4 h-4 mr-2" /> Apply Now
                </Button>
              </a>
            )}
            {exam.officialWebsite && (
              <a
                href={exam.officialWebsite}
                target="_blank"
                rel="noopener noreferrer"
                className={exam.applicationLink ? '' : 'flex-1'}
              >
                <Button className={`h-12 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-2xl text-sm font-bold shadow-lg shadow-blue-200 hover:shadow-xl transition-all ${exam.applicationLink ? 'px-4' : 'w-full'}`}>
                  <Globe className="w-4 h-4 mr-2" /> Official Website
                </Button>
              </a>
            )}
          </div>

          {/* No details message */}
          {detailItems.length === 0 && !exam.importantDates && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 text-center">
                <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">No detailed information available yet</p>
                <p className="text-gray-300 text-xs mt-1">Admin can add details from the admin panel</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // ===== RENDER: Bottom Navigation =====
  function renderBottomNav() {
    const pages: Page[] = ['home', 'practice', 'tests', 'leaderboard']
    if (!pages.includes(currentPage)) return null

    const navItems = [
      { page: 'home' as Page, icon: Home, label: _t('nav.home') },
      { page: 'practice' as Page, icon: Zap, label: _t('nav.practice') },
      { page: 'tests' as Page, icon: ClipboardList, label: _t('nav.tests') },
      { page: 'leaderboard' as Page, icon: Trophy, label: _t('nav.ranks') },
    ]

    return (
      <div className="fixed bottom-0 left-0 right-0 z-40 safe-area-pb" style={{ touchAction: 'manipulation' }}>
        <div className="bg-white/95 backdrop-blur-lg border-t border-gray-100 w-full">
          <div className="flex items-center justify-around py-2">
            {navItems.map(item => {
              const isActive = currentPage === item.page
              const Icon = item.icon
              return (
                <button
                  key={item.page}
                  onClick={() => handleBottomNav(item.page)}
                  onTouchEnd={(e) => { e.preventDefault(); handleBottomNav(item.page) }}
                  className={`flex flex-col items-center gap-0.5 py-1 px-4 rounded-xl transition-all ${
                    isActive ? 'text-orange-600' : 'text-gray-400 active:text-gray-600'
                  }`}
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                >
                  <div className={`relative ${isActive ? '' : ''}`}>
                    <Icon className={`w-5 h-5 ${isActive ? 'text-orange-600' : ''}`} />
                    {isActive && (
                      <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-orange-500" />
                    )}
                  </div>
                  <span className={`text-[10px] font-medium ${isActive ? 'text-orange-600' : ''}`}>{item.label}</span>
                </button>
              )
            })}
          </div>
        </div>
      </div>
    )
  }

  // ===== NOTIFICATION DETAIL PAGE =====
  function renderNotificationDetail() {
    const notif = selectedNotification
    if (!notif) return null

    const handleAction = () => {
      if (notif.actionUrl) {
        window.open(notif.actionUrl, '_blank', 'noopener,noreferrer')
      }
    }

    return (
      <div className="min-h-screen min-h-dvh bg-slate-50">
        {/* Header */}
        <div className={`relative text-white overflow-hidden ${
          notif.type === 'update' ? 'bg-gradient-to-br from-blue-500 via-indigo-500 to-blue-600' :
          notif.type === 'alert' ? 'bg-gradient-to-br from-amber-500 via-orange-500 to-red-500' :
          'bg-gradient-to-br from-emerald-500 via-teal-500 to-green-600'
        }`}>
          {notif.imageUrl && (
            <>
              <img src={notif.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30" />
              <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60" />
            </>
          )}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-8 w-24 h-24 rounded-full border-4 border-white" />
            <div className="absolute bottom-3 right-10 w-16 h-16 rounded-full border-4 border-white" />
          </div>
          <div className="relative z-10 px-3 pt-[calc(env(safe-area-inset-top,0px)+0.75rem)] pb-6">
            <div className="flex items-center gap-3 mb-4">
              <button
                onClick={goBack}
                className="w-9 h-9 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors flex-shrink-0"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-white/60 text-[10px] uppercase tracking-wider font-medium">Notification</p>
              </div>
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                notif.type === 'update' ? 'bg-blue-400/30' : notif.type === 'alert' ? 'bg-amber-400/30' : 'bg-emerald-400/30'
              }`}>
                {notif.type === 'update' ? <Zap className="w-5 h-5 text-white" /> : notif.type === 'alert' ? <AlertTriangle className="w-5 h-5 text-white" /> : <Gift className="w-5 h-5 text-white" />}
              </div>
            </div>
            <h1 className="text-xl font-bold leading-tight drop-shadow-lg">{notif.title}</h1>
            <div className="flex items-center gap-2 mt-2">
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                notif.type === 'update' ? 'bg-blue-400/30 text-blue-100' :
                notif.type === 'alert' ? 'bg-amber-400/30 text-amber-100' :
                'bg-emerald-400/30 text-emerald-100'
              }`}>
                {notif.type === 'update' ? 'Update' : notif.type === 'alert' ? 'Alert' : 'Info'}
              </span>
              <span className="text-white/60 text-xs">{notif.time}</span>
            </div>
          </div>
        </div>

        <div className="px-3 -mt-3 pb-6 space-y-3">
          {/* Image Card */}
          {notif.imageUrl && (
            <Card className="border-0 shadow-lg overflow-hidden">
              <div className="relative">
                <img src={notif.imageUrl} alt="" className="w-full max-h-80 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>
            </Card>
          )}

          {/* Message Content Card */}
          <Card className="border-0 shadow-md">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md overflow-hidden ${
                  notif.type === 'update' ? 'bg-gradient-to-br from-blue-400 to-indigo-500' :
                  notif.type === 'alert' ? 'bg-gradient-to-br from-amber-400 to-orange-500' :
                  'bg-gradient-to-br from-emerald-400 to-teal-500'
                }`}>
                  {notif.imageUrl ? (
                    <img src={notif.imageUrl} alt="" className="w-12 h-12 object-cover rounded-2xl" />
                  ) : (
                    notif.type === 'update' ? <Zap className="w-6 h-6 text-white" /> : notif.type === 'alert' ? <AlertTriangle className="w-6 h-6 text-white" /> : <Gift className="w-6 h-6 text-white" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h2 className="font-bold text-base text-gray-800">{notif.title}</h2>
                  <p className="text-xs text-gray-400 mt-0.5">{notif.time}</p>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-wrap">{notif.message}</p>
              </div>
            </CardContent>
          </Card>

          {/* Action URL Button */}
          {notif.actionUrl && (
            <Card className="border-0 shadow-md">
              <CardContent className="p-4">
                <Button
                  onClick={handleAction}
                  className={`w-full text-white rounded-xl h-12 font-semibold text-sm ${
                    notif.type === 'update' ? 'bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600' :
                    notif.type === 'alert' ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600' :
                    'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600'
                  }`}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Link
                </Button>
                <p className="text-[10px] text-gray-400 mt-2 text-center break-all">{notif.actionUrl}</p>
              </CardContent>
            </Card>
          )}

          {/* Other Notifications */}
          {notifications.filter(n => n.id !== notif.id).length > 0 && (
            <Card className="border-0 shadow-md">
              <CardContent className="p-4">
                <h3 className="font-bold text-sm text-gray-700 mb-3">More Notifications</h3>
                <div className="space-y-2">
                  {notifications.filter(n => n.id !== notif.id).slice(0, 5).map((otherNotif) => (
                    <button
                      key={otherNotif.id}
                      onClick={() => { setSelectedNotification(otherNotif); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
                      className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl bg-gray-50 hover:bg-gray-100 active:bg-gray-200 transition-colors"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden ${
                        otherNotif.type === 'update' ? 'bg-blue-100' : otherNotif.type === 'alert' ? 'bg-amber-100' : 'bg-green-100'
                      }`}>
                        {otherNotif.imageUrl ? (
                          <img src={otherNotif.imageUrl} alt="" className="w-8 h-8 object-cover rounded-full" />
                        ) : (
                          otherNotif.type === 'update' ? <Zap className="w-4 h-4 text-blue-500" /> : otherNotif.type === 'alert' ? <AlertTriangle className="w-4 h-4 text-amber-500" /> : <Gift className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">{otherNotif.title}</p>
                        <p className="text-[10px] text-gray-400 truncate">{otherNotif.message}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // ===== DAILY TIP DETAIL PAGE =====
  function renderDailyTipDetail() {
    const tip = selectedDailyTip
    if (!tip) return null

    return (
      <div className="min-h-screen min-h-dvh bg-slate-50">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-amber-500 via-orange-500 to-red-500 text-white overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-8 w-28 h-28 rounded-full border-4 border-white" />
            <div className="absolute bottom-3 right-10 w-20 h-20 rounded-full border-4 border-white" />
            <div className="absolute top-12 right-20 w-8 h-8 rounded-full bg-white" />
          </div>
          <div className="relative z-10 px-3 pt-[calc(env(safe-area-inset-top,0px)+0.75rem)] pb-5">
            <div className="flex items-center gap-3 mb-4">
              <button
                onClick={goBack}
                className="w-9 h-9 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors flex-shrink-0"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-white/60 text-[10px] uppercase tracking-wider font-medium">{_t('home.dailyTips')}</p>
              </div>
              <div className="w-9 h-9 rounded-lg bg-white/15 flex items-center justify-center">
                <Star className="w-5 h-5 text-white" />
              </div>
            </div>
            <h1 className="text-xl font-bold leading-tight">Daily Tip</h1>
          </div>
        </div>

        <div className="px-3 -mt-3 pb-6 space-y-3">
          {/* Image Card */}
          {tip.imageUrl && (
            <Card className="border-0 shadow-lg overflow-hidden">
              <div className="relative">
                <img src={tip.imageUrl} alt="" className="w-full max-h-80 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
              </div>
            </Card>
          )}

          {/* Tip Content Card */}
          <Card className="border-0 shadow-md">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center flex-shrink-0 shadow-md">
                  <Star className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h2 className="font-bold text-base text-gray-800 mb-2">{_t('home.dailyTips')}</h2>
                  <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-wrap">{tip.text}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* More Tips Section */}
          {dailyTips.filter(t => t.id !== tip.id).length > 0 && (
            <Card className="border-0 shadow-md">
              <CardContent className="p-4">
                <h3 className="font-bold text-sm text-gray-700 mb-3">More Tips</h3>
                <div className="space-y-2">
                  {dailyTips.filter(t => t.id !== tip.id).slice(0, 5).map((otherTip) => (
                    <button
                      key={otherTip.id}
                      onClick={() => { setSelectedDailyTip(otherTip); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
                      className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl bg-amber-50/60 hover:bg-amber-50 active:bg-amber-100 transition-colors"
                    >
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center flex-shrink-0">
                        <Star className="w-4 h-4 text-white" />
                      </div>
                      <p className="text-xs text-gray-600 leading-relaxed flex-1 line-clamp-2">{otherTip.text}</p>
                      <ChevronRight className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // ===== ANNOUNCEMENT DETAIL PAGE =====
  function renderAnnouncementDetail() {
    const ann = selectedAnnouncement
    if (!ann) return null

    return (
      <div className="min-h-screen min-h-dvh bg-slate-50">
        {/* Header with gradient/image */}
        <div className={`relative bg-gradient-to-br ${ann.gradient} text-white overflow-hidden`}>
          {ann.imageUrl && (
            <>
              <img src={ann.imageUrl} alt={ann.title} className="absolute inset-0 w-full h-full object-cover opacity-40" />
              <div className={`absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60`} />
            </>
          )}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-8 w-28 h-28 rounded-full border-4 border-white" />
            <div className="absolute bottom-3 right-10 w-20 h-20 rounded-full border-4 border-white" />
          </div>
          <div className="relative z-10 px-3 pt-[calc(env(safe-area-inset-top,0px)+0.75rem)] pb-6">
            <div className="flex items-center gap-3 mb-4">
              <button
                onClick={goBack}
                className="w-9 h-9 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors flex-shrink-0"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-white/60 text-[10px] uppercase tracking-wider font-medium">Announcement</p>
              </div>
              {!ann.imageUrl && (
                <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
                  {ann.image === 'ssc' && <BookOpen className="w-5 h-5 text-white" />}
                  {ann.image === 'banking' && <Building className="w-5 h-5 text-white" />}
                  {ann.image === 'leaderboard' && <Trophy className="w-5 h-5 text-white" />}
                  {ann.image === 'practice' && <Zap className="w-5 h-5 text-white" />}
                </div>
              )}
            </div>
            <h1 className="text-2xl font-bold leading-tight drop-shadow-lg">{ann.title}</h1>
            <p className="text-white/80 text-sm mt-2 leading-relaxed drop-shadow-md">{ann.subtitle}</p>
          </div>
        </div>

        <div className="px-3 -mt-3 pb-6 space-y-3">
          {/* Full Image Card */}
          {ann.imageUrl && (
            <Card className="border-0 shadow-lg overflow-hidden">
              <div className="relative">
                <img src={ann.imageUrl} alt={ann.title} className="w-full max-h-96 object-cover" />
              </div>
            </Card>
          )}

          {/* Action Card */}
          <Card className="border-0 shadow-md">
            <CardContent className="p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${ann.gradient} flex items-center justify-center flex-shrink-0`}>
                  {ann.image === 'ssc' && <BookOpen className="w-5 h-5 text-white" />}
                  {ann.image === 'banking' && <Building className="w-5 h-5 text-white" />}
                  {ann.image === 'leaderboard' && <Trophy className="w-5 h-5 text-white" />}
                  {ann.image === 'practice' && <Zap className="w-5 h-5 text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm text-gray-800">{ann.title}</p>
                  <p className="text-gray-500 text-xs">{ann.subtitle}</p>
                </div>
              </div>
              <Button
                onClick={() => handleBottomNav(ann.action)}
                className={`w-full bg-gradient-to-r ${ann.gradient} hover:opacity-90 text-white rounded-xl h-11 font-semibold`}
              >
                <span className="capitalize">{ann.action === 'exams' ? 'View Exams' : ann.action === 'leaderboard' ? 'Leaderboard' : ann.action === 'practice' ? 'Practice Now' : 'Explore'}</span>
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </CardContent>
          </Card>

          {/* Other Announcements */}
          {announcements.filter(a => a.id !== ann.id).length > 0 && (
            <Card className="border-0 shadow-md">
              <CardContent className="p-4">
                <h3 className="font-bold text-sm text-gray-700 mb-3">More Announcements</h3>
                <div className="space-y-2">
                  {announcements.filter(a => a.id !== ann.id).slice(0, 5).map((otherAnn) => (
                    <button
                      key={otherAnn.id}
                      onClick={() => { setSelectedAnnouncement(otherAnn); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
                      className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl bg-gray-50 hover:bg-gray-100 active:bg-gray-200 transition-colors"
                    >
                      <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${otherAnn.gradient} flex items-center justify-center flex-shrink-0`}>
                        {otherAnn.image === 'ssc' && <BookOpen className="w-4 h-4 text-white" />}
                        {otherAnn.image === 'banking' && <Building className="w-4 h-4 text-white" />}
                        {otherAnn.image === 'leaderboard' && <Trophy className="w-4 h-4 text-white" />}
                        {otherAnn.image === 'practice' && <Zap className="w-4 h-4 text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">{otherAnn.title}</p>
                        <p className="text-[10px] text-gray-400 truncate">{otherAnn.subtitle}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // ===== MAIN RENDER =====
  const renderPage = () => {
    switch (currentPage) {
      case 'home': return renderHome()
      case 'exams': return renderExams()
      case 'tests': return renderTests()
      case 'test-info': return renderTestInfo()
      case 'test-taking': return renderTestTaking()
      case 'results': return renderResults()
      case 'leaderboard': return renderLeaderboard()
      case 'profile': return renderProfile()
      case 'practice': return renderPractice()
      case 'bookmarks': return renderBookmarks()
      case 'perf-report': return renderPerfReport()
      case 'daily-routine': return renderDailyRoutine()
      case 'prev-papers': return renderPrevPapers()
      case 'your-exam': return renderYourExam()
      case 'upcoming-exam-detail': return renderUpcomingExamDetail()
      case 'daily-tip-detail': return renderDailyTipDetail()
      case 'announcement-detail': return renderAnnouncementDetail()
      case 'notification-detail': return renderNotificationDetail()
      default: return renderHome()
    }
  }

  return (
    <div className="min-h-screen min-h-dvh bg-gray-50 relative w-full overflow-x-hidden" style={{ touchAction: 'manipulation' }}>
      {/* ===== Splash Screen ===== */}
      {showSplash && (
        <div className={`fixed inset-0 z-[200] flex items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 ${splashFading ? 'animate-splash-fade-out' : ''}`} style={{ perspective: '1200px' }}>
          {/* Decorative background elements */}
          <div className="absolute top-1/4 left-1/4 w-48 h-48 bg-orange-500/8 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-blue-500/8 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-purple-500/5 rounded-full blur-3xl" />

          <div className="flex flex-col items-center relative z-10">
            {/* Book opening animation container */}
            <div className="relative w-40 h-52 mb-8" style={{ perspective: '1200px', transformStyle: 'preserve-3d' }}>
              {/* Book spine (center) */}
              <div className="absolute left-1/2 top-0 bottom-0 w-1 -translate-x-1/2 bg-gradient-to-b from-amber-600 via-amber-700 to-amber-800 rounded-sm z-10 shadow-lg shadow-amber-900/50" />

              {/* Left page (behind) */}
              <div className="absolute inset-0 right-1/2 mr-0.5 rounded-l-lg bg-gradient-to-br from-amber-50 to-orange-50 shadow-inner border border-amber-200/50 overflow-hidden">
                <div className="absolute inset-2 flex flex-col gap-1.5 pt-3 px-2">
                  <div className="h-1 bg-amber-200/60 rounded-full w-3/4" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-full" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-5/6" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-full" />
                  <div className="h-3" />
                  <div className="h-1 bg-amber-200/60 rounded-full w-2/3" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-full" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-4/5" />
                  <div className="h-3" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-full" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-3/4" />
                </div>
              </div>

              {/* Right page (behind) */}
              <div className="absolute inset-0 left-1/2 ml-0.5 rounded-r-lg bg-gradient-to-bl from-amber-50 to-orange-50 shadow-inner border border-amber-200/50 overflow-hidden">
                <div className="absolute inset-2 flex flex-col items-center justify-center">
                  {/* Question icon pattern */}
                  <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mb-2">
                    <span className="text-orange-400 font-bold text-sm">?</span>
                  </div>
                  <div className="h-1 bg-amber-200/40 rounded-full w-3/4 mb-1" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-full mb-1" />
                  <div className="h-1 bg-amber-200/40 rounded-full w-5/6 mb-3" />
                  <div className="flex gap-1">
                    <div className="w-5 h-5 rounded bg-emerald-100 border border-emerald-200" />
                    <div className="w-5 h-5 rounded bg-red-100 border border-red-200" />
                  </div>
                </div>
              </div>

              {/* Left cover (opens left) */}
              <div className="absolute inset-0 right-1/2 mr-0.5 rounded-l-xl bg-gradient-to-br from-orange-500 via-rose-500 to-red-600 shadow-xl animate-book-open-left origin-right" style={{ transformStyle: 'preserve-3d', animationDelay: '0.8s' }}>
                <div className="absolute inset-0 flex items-center justify-center rounded-l-xl overflow-hidden">
                  <div className="animate-splash-shimmer absolute inset-0" />
                  <div className="flex flex-col items-center">
                    <BookOpen className="w-10 h-10 text-white/90 mb-1" />
                    <div className="h-0.5 w-8 bg-white/40 rounded-full" />
                  </div>
                </div>
                {/* Spine edge */}
                <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-orange-700 to-red-800" />
              </div>

              {/* Right cover (opens right) */}
              <div className="absolute inset-0 left-1/2 ml-0.5 rounded-r-xl bg-gradient-to-bl from-orange-500 via-rose-500 to-red-600 shadow-xl animate-book-open-right origin-left" style={{ transformStyle: 'preserve-3d', animationDelay: '0.8s' }}>
                <div className="absolute inset-0 flex items-center justify-center rounded-r-xl overflow-hidden">
                  <div className="animate-splash-shimmer absolute inset-0" />
                  <div className="flex flex-col items-center">
                    <Trophy className="w-10 h-10 text-white/90 mb-1" />
                    <div className="h-0.5 w-8 bg-white/40 rounded-full" />
                  </div>
                </div>
                {/* Spine edge */}
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-orange-700 to-red-800" />
              </div>
            </div>

            {/* Logo */}
            <div className="animate-splash-logo mb-5">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-orange-400 via-rose-500 to-pink-500 flex items-center justify-center shadow-2xl shadow-orange-500/30 ring-3 ring-white/20">
                <img src="/logo.png" alt="MockMaster" className="w-16 h-16 rounded-2xl" />
              </div>
            </div>

            {/* App Name */}
            <h1 className="animate-splash-text text-white font-extrabold text-3xl tracking-tight mb-2">
              MockMaster
            </h1>

            {/* Tagline */}
            <p className="animate-splash-text-delay text-white/50 text-sm font-medium tracking-wide">
              Your Exam Preparation Partner
            </p>

            {/* Loading indicator */}
            <div className="animate-splash-text-delay mt-8 flex items-center gap-2">
              <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-orange-400 animate-splash-pulse" style={{ animationDelay: '0s' }} />
                <div className="w-2 h-2 rounded-full bg-rose-400 animate-splash-pulse" style={{ animationDelay: '0.3s' }} />
                <div className="w-2 h-2 rounded-full bg-pink-400 animate-splash-pulse" style={{ animationDelay: '0.6s' }} />
              </div>
              <span className="text-white/30 text-xs font-medium">Loading</span>
            </div>
          </div>
        </div>
      )}

      {renderPage()}
      {renderBottomNav()}

      {/* ===== Exit App Confirmation Dialog ===== */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[150] flex items-center justify-center p-5">
          <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden animate-scale-in">
            <div className="p-6 pb-4 text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-100 to-orange-50 flex items-center justify-center mx-auto mb-4">
                <LogOut className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="font-bold text-xl text-gray-900">{_t('exitApp.title')}</h3>
              <p className="text-gray-500 text-sm mt-2 leading-relaxed">
                {_t('exitApp.message')}
              </p>
            </div>
            <div className="px-6 pb-6 space-y-2.5">
              <Button
                className="w-full h-11 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-semibold text-sm"
                onClick={() => setShowExitConfirm(false)}
              >
                {_t('exitApp.noStay')}
              </Button>
              <Button
                variant="outline"
                className="w-full h-11 rounded-xl border-gray-200 text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200 font-semibold text-sm"
                onClick={() => {
                  setShowExitConfirm(false)
                  App.exitApp?.()
                }}
              >
                {_t('exitApp.yesExit')}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Side Menu Drawer ===== */}
      {showSideMenu && (
        <div className="fixed inset-0 z-[100]">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowSideMenu(false)}
            onTouchEnd={(e) => { e.preventDefault(); setShowSideMenu(false) }}
            style={{ touchAction: 'manipulation' }}
          />
          {/* Drawer Panel */}
          <div className="absolute left-0 top-0 bottom-0 w-[280px] bg-white shadow-2xl flex flex-col" style={{ touchAction: 'manipulation' }}>
            {/* Drawer Header - Compact Premium Profile */}
            <div className="relative px-4 pt-[calc(env(safe-area-inset-top,0px)+0.75rem)] pb-3 overflow-hidden" style={{ background: 'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)' }}>
              {/* Decorative glow */}
              <div className="absolute -top-4 -right-4 w-20 h-20 rounded-full" style={{ background: 'radial-gradient(circle, rgba(251,146,60,0.15) 0%, transparent 70%)' }} />
              <div className="absolute bottom-0 left-2 w-14 h-14 rounded-full" style={{ background: 'radial-gradient(circle, rgba(139,92,246,0.1) 0%, transparent 70%)' }} />

              {/* Close button row */}
              <div className="flex items-center justify-end mb-2 relative z-10">
                <button
                  onClick={() => setShowSideMenu(false)}
                  onTouchEnd={(e) => { e.preventDefault(); setShowSideMenu(false) }}
                  className="w-7 h-7 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center"
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                >
                  <X className="w-3.5 h-3.5 text-white/70" />
                </button>
              </div>

              {/* Profile Section - Clickable */}
              <button
                onClick={() => { handleBottomNav('profile'); setShowSideMenu(false) }}
                onTouchEnd={(e) => { e.preventDefault(); handleBottomNav('profile'); setShowSideMenu(false) }}
                className="w-full relative z-10 text-left active:scale-[0.97] transition-transform"
                style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
              >
                {auth.isLoggedIn ? (
                  <div className="flex items-center gap-3">
                    {/* Student Photo */}
                    <div className="relative flex-shrink-0">
                      <div className="w-11 h-11 rounded-full bg-gradient-to-br from-orange-300 via-rose-400 to-purple-500 p-[2px] shadow-lg shadow-orange-400/20">
                        <div className="w-full h-full rounded-full bg-gradient-to-br from-slate-900/90 to-indigo-900/90 flex items-center justify-center overflow-hidden">
                          {auth.user?.photoURL ? (
                            <img src={auth.user.photoURL} alt="Profile" className="w-full h-full rounded-full object-cover" />
                          ) : (
                            <span className="text-white text-base font-extrabold">{getAvatarDisplay()}</span>
                          )}
                        </div>
                      </div>
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 rounded-full border-2 border-[#302b63]" />
                    </div>
                    {/* Student Name */}
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-bold text-[14px] truncate">{auth.user?.displayName || auth.user?.email?.split('@')[0] || 'Student'}</p>
                      <p className="text-white/40 text-[10px] truncate">{auth.user?.email || ''}</p>
                    </div>
                    {/* Edit icon */}
                    <div className="flex-shrink-0 w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center">
                      <Edit3 className="w-3.5 h-3.5 text-orange-300" />
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-slate-700 flex items-center justify-center ring-1 ring-white/10 flex-shrink-0">
                      <User className="w-5 h-5 text-white/40" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white/60 font-semibold text-[12px]">{_t('home.loginTrack')}</p>
                      <p className="text-white/25 text-[10px]">{_t('home.loginTrackSub')}</p>
                    </div>
                    <div className="flex-shrink-0 w-7 h-7 rounded-lg bg-gradient-to-r from-orange-500 to-rose-500 flex items-center justify-center shadow shadow-orange-500/30">
                      <Mail className="w-3 h-3 text-white" />
                    </div>
                  </div>
                )}
              </button>
            </div>

            {/* Menu Items - All Admin Managed */}
            <div className="flex-1 overflow-y-auto py-3 px-3" onTouchStart={(e) => { sideMenuScrollRef.current = { y: e.touches[0].clientY, x: e.touches[0].clientX, t: Date.now() } }} onTouchMove={(e) => { if (sideMenuScrollRef.current) { const dy = Math.abs(e.touches[0].clientY - sideMenuScrollRef.current.y); const dx = Math.abs(e.touches[0].clientX - sideMenuScrollRef.current.x); if (dy > 8 || dx > 8) sideMenuScrollRef.current.scrolled = true } }} onTouchEnd={() => { setTimeout(() => { if (sideMenuScrollRef.current) sideMenuScrollRef.current.scrolled = false }, 50) }}>
              {/* All menu items from admin (sidebarMenu) */}
              <div className="mb-2">
                {(sidebarMenu.length > 0 ? sidebarMenu : DEFAULT_SIDEBAR_MENU_ITEMS).filter(i => i.visible).sort((a, b) => a.order - b.order).map((item, i) => {
                  const IconComp = SIDEBAR_ICON_MAP[item.icon] || Zap
                  const pageColors = SIDEBAR_PAGE_COLORS[item.page] || { lightBg: 'bg-gray-50', textColor: 'text-gray-700' }
                  const isActive = currentPage === item.page
                  const isNavPage = ['home', 'exams', 'leaderboard'].includes(item.page)
                  return (
                    <button
                      key={item.id || i}
                      onClick={() => { if (!sideMenuScrollRef.current?.scrolled) { isNavPage ? handleBottomNav(item.page as Page) : navigateTo(item.page as Page); setShowSideMenu(false) } }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 mb-0.5 ${
                        isActive
                          ? `${pageColors.lightBg} ${pageColors.textColor} shadow-sm border border-white/60`
                          : 'text-gray-600 hover:bg-gray-50 active:bg-gray-100'
                      }`}
                      style={{ touchAction: 'pan-y', WebkitTapHighlightColor: 'transparent' }}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                        isActive
                          ? `bg-gradient-to-br ${item.gradient} shadow-sm`
                          : 'bg-gray-100'
                      }`}>
                        <IconComp className={`w-4 h-4 ${isActive ? 'text-white' : 'text-gray-400'}`} />
                      </div>
                      <span className={`font-medium text-[13px] flex-1 text-left ${isActive ? 'font-bold' : ''}`}>{item.label}</span>
                      {isActive && (
                        <div className={`w-6 h-1.5 rounded-full bg-gradient-to-r ${item.gradient}`} />
                      )}
                    </button>
                  )
                })}
              </div>

              <div className="flex items-center gap-2 px-3 my-2">
                <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent" />
              </div>

              {/* Settings & Support */}
              <div className="mb-2">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-3 mb-2">{_t('menu.settings')}</p>
                {[
                  { icon: BookOpen, id: 'language', label: _t('profile.language'), sub: lng === 'en' ? _t('lang.english') : lng === 'hi' ? _t('lang.hindi') : _t('lang.bangla'), action: () => setShowLanguageSheet(true), soon: false, gradient: 'from-indigo-400 to-blue-500', lightBg: 'bg-indigo-50', iconInactive: 'text-indigo-400' },
                  { icon: Wifi, id: 'offline', label: _t('menu.offlineMode'), sub: _t('menu.downloadTests'), action: () => {}, soon: true, gradient: 'from-teal-400 to-emerald-500', lightBg: 'bg-teal-50', iconInactive: 'text-teal-400' },
                  { icon: HelpCircle, id: 'help', label: _t('menu.helpFaq'), sub: _t('menu.getSupport'), action: () => setShowFaqSheet(true), soon: false, gradient: 'from-cyan-400 to-sky-500', lightBg: 'bg-cyan-50', iconInactive: 'text-cyan-400' },
                  { icon: Share2, id: 'share', label: _t('menu.shareApp'), sub: _t('menu.tellFriends'), action: () => {
                    if (navigator.share) {
                      navigator.share({ title: _t('app.name'), text: _t('share.text'), url: window.location.href })
                    }
                  }, soon: false, gradient: 'from-pink-400 to-rose-500', lightBg: 'bg-pink-50', iconInactive: 'text-pink-400' },
                  { icon: Shield, id: 'about', label: _t('menu.about'), sub: _t('app.version'), action: () => setShowAboutSheet(true), soon: false, gradient: 'from-slate-400 to-gray-500', lightBg: 'bg-slate-50', iconInactive: 'text-slate-400' },
                ].map((item, i) => (
                  <button
                    key={i}
                    onClick={() => { if (!sideMenuScrollRef.current?.scrolled && !item.soon) { setShowSideMenu(false); setTimeout(() => item.action(), 150) } }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 mb-0.5 ${item.soon ? 'opacity-60' : 'text-gray-600 hover:bg-gray-50 active:bg-gray-100'}`}
                    style={{ touchAction: 'pan-y', WebkitTapHighlightColor: 'transparent' }}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${item.soon ? 'bg-gray-100' : item.lightBg}`}>
                      <item.icon className={`w-4 h-4 ${item.soon ? 'text-gray-300' : item.iconInactive}`} />
                    </div>
                    <div className="flex-1 text-left">
                      <span className="font-medium text-[13px] block">{item.label}</span>
                      {item.sub && <span className="text-gray-400 text-[10px]">{item.sub}</span>}
                    </div>
                    {item.soon ? (
                      <span className="text-[9px] font-bold text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{_t('menu.soon')}</span>
                    ) : (
                      <ChevronRight className="w-4 h-4 text-gray-300" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="px-4 py-4 bg-gradient-to-r from-gray-50 to-slate-50">
              {auth.isLoggedIn ? (
                <button
                  onClick={() => { auth.logout(); setShowSideMenu(false) }}
                  onTouchEnd={(e) => { e.preventDefault(); auth.logout(); setShowSideMenu(false) }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 bg-red-50 hover:bg-red-100 active:bg-red-200 transition-all border border-red-100"
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                >
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-red-400 to-rose-500 flex items-center justify-center shadow-sm">
                    <LogOut className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-bold text-[13px]">{_t('menu.logout')}</span>
                </button>
              ) : (
                <button
                  onClick={() => { setShowLoginModal(true); setShowSideMenu(false) }}
                  onTouchEnd={(e) => { e.preventDefault(); setShowLoginModal(true); setShowSideMenu(false) }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-orange-500 via-rose-500 to-pink-500 text-white rounded-xl font-bold text-[13px] shadow-lg shadow-orange-500/25 active:scale-[0.98] transition-all"
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent' }}
                >
                  <Mail className="w-4 h-4" /> {_t('profile.login')}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Language Sheet - Global */}
      {showLanguageSheet && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110] flex items-end justify-center" onClick={() => setShowLanguageSheet(false)}>
          <div className="bg-white rounded-t-[28px] w-full p-6 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-gray-200 mx-auto mb-5" />
            <h3 className="font-bold text-lg mb-4">{_t('lang.select')}</h3>
            <div className="space-y-1">
              {[
                { code: 'en', name: _t('lang.english'), flag: '🇬🇧', available: true },
                { code: 'hi', name: _t('lang.hindi'), flag: '🇮🇳', available: true },
                { code: 'bn', name: _t('lang.bangla'), flag: '🇧🇩', available: true },
              ].map(lang => (
                <button
                  key={lang.code}
                  className={`w-full flex items-center gap-3 p-4 rounded-xl transition-colors ${
                    lang.available ? 'hover:bg-gray-50 active:bg-gray-100' : 'opacity-50'
                  }`}
                  onClick={() => {
                    if (lang.available) {
                      setSelectedLanguage(lang.code)
                      setShowLanguageSheet(false)
                    }
                  }}
                  onTouchEnd={(e) => {
                    if (lang.available) {
                      e.preventDefault()
                      setSelectedLanguage(lang.code)
                      setShowLanguageSheet(false)
                    }
                  }}
                >
                  <span className="text-xl">{lang.flag}</span>
                  <span className="font-medium text-sm flex-1">{lang.name}</span>
                  {!lang.available && <Badge variant="secondary" className="text-[10px]">{_t('lang.comingSoon')}</Badge>}
                  {selectedLanguage === lang.code && (
                    <div className="w-6 h-6 rounded-full bg-orange-500 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                  )}
                </button>
              ))}
            </div>
            <Button
              variant="outline"
              className="w-full mt-5 rounded-xl h-11"
              onClick={() => setShowLanguageSheet(false)}
            >
              {_t('lang.cancel')}
            </Button>
          </div>
        </div>
      )}

      {/* About Sheet - Global */}
      {showAboutSheet && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110] flex items-end justify-center" onClick={() => setShowAboutSheet(false)}>
          <div className="bg-white rounded-t-[28px] w-full p-6 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-gray-200 mx-auto mb-5" />
            <div className="text-center mb-5">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg shadow-orange-500/20">
                <span className="text-white text-2xl font-bold">E</span>
              </div>
              <h3 className="font-bold text-lg">{_t('app.name')}</h3>
              <p className="text-gray-400 text-sm">{_t('app.version')}</p>
            </div>
            <div className="space-y-2">
              {[
                { label: _t('about.version'), value: '1.0' },
                { label: _t('about.size'), value: '~5 MB' },
                { label: _t('about.exams'), value: '21+' },
                { label: _t('about.questions'), value: '210+' },
                { label: _t('about.offline'), value: _t('about.yes'), green: true },
                { label: _t('about.ads'), value: _t('about.no'), green: true },
              ].map(item => (
                <div key={item.label} className="flex justify-between text-sm p-3 bg-gray-50 rounded-xl">
                  <span className="text-gray-500">{item.label}</span>
                  <span className={`font-medium ${item.green ? 'text-emerald-600' : ''}`}>{item.value}</span>
                </div>
              ))}
            </div>
            <p className="text-center text-sm text-gray-400 mt-5">{_t('app.madeIn')}</p>
            <Button
              variant="outline"
              className="w-full mt-4 rounded-xl h-11"
              onClick={() => setShowAboutSheet(false)}
            >
              {_t('about.close')}
            </Button>
          </div>
        </div>
      )}

      {/* FAQ Sheet - Global */}
      {showFaqSheet && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110] flex items-end justify-center" onClick={() => setShowFaqSheet(false)}>
          <div className="bg-white rounded-t-[28px] w-full p-6 animate-slide-up max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-gray-200 mx-auto mb-5" />
            <h3 className="font-bold text-lg mb-4">{_t('faq.title')}</h3>
            <div className="space-y-3">
              {Array.from({ length: 7 }, (_, i) => i + 1).map(n => (
                <div key={n} className="bg-gray-50 rounded-xl p-3">
                  <p className="font-semibold text-sm text-gray-800">{_t(`faq.q${n}`)}</p>
                  <p className="text-gray-500 text-xs mt-1 leading-relaxed">{_t(`faq.a${n}`)}</p>
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              className="w-full mt-5 rounded-xl h-11"
              onClick={() => setShowFaqSheet(false)}
            >
              {_t('about.close')}
            </Button>
          </div>
        </div>
      )}

      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal
          error={auth.error}
          loginLoading={auth.loginLoading}
          signupLoading={auth.signupLoading}
          guestLoading={auth.guestLoading}
          resetLoading={auth.resetLoading}
          verifyLoading={auth.verifyLoading}
          resetSent={auth.resetSent}
          verifySent={auth.verifySent}
          needsVerification={auth.needsVerification}
          pendingVerifyEmail={auth.pendingVerifyEmail}
          onLogin={auth.loginWithEmail}
          onSignUp={auth.signUpWithEmail}
          onGuestLogin={auth.loginAsGuest}
          onPasswordReset={auth.sendPasswordReset}
          onResendVerification={auth.resendVerificationWithCredentials}
          onClearError={() => auth.setError('')}
          onClearResetSent={() => auth.setResetSent(false)}
          onClearVerifySent={() => auth.setVerifySent(false)}
          onClearNeedsVerification={() => { auth.setNeedsVerification(false); auth.setPendingVerifyEmail('') }}
          onClose={() => { auth.setError(''); auth.setResetSent(false); auth.setVerifySent(false); auth.setNeedsVerification(false); auth.setPendingVerifyEmail(''); setShowLoginModal(false) }}
        />
      )}

      {/* Guest Auth Modal - Two modes: QP limit & login required */}
      {showGuestAuthModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setShowGuestAuthModal(false)}>
          <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl" onClick={e => e.stopPropagation()}>
            {/* Header with gradient */}
            <div className={`p-6 text-center relative overflow-hidden ${guestAuthMode === 'qp-limit' ? 'bg-gradient-to-br from-orange-500 via-red-500 to-pink-500' : 'bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-600'}`}>
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />
              <div className="relative">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-3 backdrop-blur">
                  {guestAuthMode === 'qp-limit' ? (
                    <Zap className="w-8 h-8 text-white" />
                  ) : (
                    <Lock className="w-8 h-8 text-white" />
                  )}
                </div>
                <h2 className="text-xl font-bold text-white">
                  {guestAuthMode === 'qp-limit' ? _t('guest.limitTitle') : _t('guest.loginTitle')}
                </h2>
              </div>
            </div>
            {/* Body */}
            <div className="p-5">
              <p className="text-gray-600 text-sm text-center leading-relaxed mb-5">
                {guestAuthMode === 'qp-limit' ? _t('guest.limitSub') : _t('guest.loginSub')}
              </p>
              {/* Features list */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3 bg-green-50 rounded-xl p-3">
                  <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                    <Zap className="w-4 h-4 text-green-600" />
                  </div>
                  <span className="text-sm font-medium text-green-800">
                    {guestAuthMode === 'qp-limit' ? _t('guest.limitFeature1') : _t('guest.loginFeature1')}
                  </span>
                </div>
                <div className="flex items-center gap-3 bg-blue-50 rounded-xl p-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                  </div>
                  <span className="text-sm font-medium text-blue-800">
                    {guestAuthMode === 'qp-limit' ? _t('guest.limitFeature2') : _t('guest.loginFeature2')}
                  </span>
                </div>
                <div className="flex items-center gap-3 bg-purple-50 rounded-xl p-3">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                    <Trophy className="w-4 h-4 text-purple-600" />
                  </div>
                  <span className="text-sm font-medium text-purple-800">
                    {guestAuthMode === 'qp-limit' ? _t('guest.limitFeature3') : _t('guest.loginFeature3')}
                  </span>
                </div>
                <div className="flex items-center gap-3 bg-amber-50 rounded-xl p-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                    <BookMarked className="w-4 h-4 text-amber-600" />
                  </div>
                  <span className="text-sm font-medium text-amber-800">
                    {guestAuthMode === 'qp-limit' ? _t('guest.limitFeature4') : _t('guest.loginFeature4')}
                  </span>
                </div>
              </div>
              {/* CTA Button */}
              <Button
                className={`w-full text-white rounded-xl h-12 font-bold text-base shadow-lg active:scale-[0.97] transition-all ${guestAuthMode === 'qp-limit' ? 'bg-gradient-to-r from-orange-500 to-red-500' : 'bg-gradient-to-r from-blue-500 to-purple-600'}`}
                onClick={() => {
                  setShowGuestAuthModal(false)
                  setShowLoginModal(true)
                }}
              >
                <UserPlus className="w-5 h-5 mr-2" /> {guestAuthMode === 'qp-limit' ? _t('guest.createAccount') : _t('guest.loginBtn')}
              </Button>
              {/* Dismiss */}
              <Button
                variant="ghost"
                className="w-full mt-2 text-gray-400 rounded-xl"
                onClick={() => setShowGuestAuthModal(false)}
              >
                {_t('guest.laterBtn')}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Secure Blur Overlay - Appears when user tries to screenshot or switches app during test */}
      <div className={`secure-blur-overlay ${secureBlurActive ? 'active' : ''}`}>
        <div className="blur-message">
          <div className="lock-icon">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h3>Content Protected</h3>
          <p>Screenshots are not allowed during the test</p>
        </div>
      </div>
    </div>
  )
}
